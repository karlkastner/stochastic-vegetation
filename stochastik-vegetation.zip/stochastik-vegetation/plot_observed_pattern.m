% Tue 20 Jul 23:47:34 CEST 2021

function analyze_band(meta)

if (nargin()<1)
	meta = vegetation_metadata();
end
pflag = meta.pflag;
fflag = pflag;

nb = 10;
nf =  1;

x0 = [ 1004
       666 ];
y0 = [  185
  	 761];
d_km = 2.71e3;
dpxl = hypot(diff(x0),diff(y0))
dx = d_km/dpxl;

name = '~/Pictures/vegetation/pattern_007.777444_047.922583.png';

img = imread(name);
img=mean(img,3);
if (nf>1)
	img=trifilt1(trifilt1(img,nf)',nf)';
end
xx = dx*(1:size(img,1))';
yy = dx*(1:size(img,2))';

[cx,cy,b,x0,y0] = improfile(img,x0(1:2),y0(1:2));
b = cvec(b);
L = dx*length(b);
%x = dx*(1:length(b))';
%x(end)-x(1);

% save
if (0)
tab = table(x,b);
writetable(tab,[name(1:end-4),'.csv']);
end

b = -b;
b = b-min(b);
b = b/rms(b);
if (0)
%b(b<0.5) = 0.5;
%b = b - ordfilt2(b,1,ones(100,1),'symmetric');
for idx=1:4; bmin = meanfilt1(ordfilt2(b,1,ones(100,1)),100); b=b-bmin; end
b = b-min(b);
b = b/mean(b);
end

% scale image grayscales
q = quantile(img(:),[0.1,0.9]);
img = max(0,min(1,(img-q(1))/(q(2)-q(1))));


% 2D plot
figure(1);
clf();
s = 1e3;
orig = [mean(dx*y0),dx*mean(x0)];
if (0)
	imagesc(yy-orig(2),xx-orig(1),img)
	hold on;
	plot(x0*dx-orig(2),y0*dx-orig(1),'r','linewidth',1.5);
else
	imagesc(1e-3*(xx-orig(1)),1e-3*(yy-orig(2)),img')
	hold on;
	plot(1e-3*(y0*dx-orig(1)),1e-3*(x0*dx-orig(2)),'r','linewidth',1.5);
end
axis equal;
s = 0.8;
ylim(1e-3*(dx*(mid(x0)+range(x0)*1.25*s*[-1,1])-[orig(2)])); 
xlim(1e-3*(dx*(mid(y0)+range(y0)*s*[-1,1])-[orig(1)])); 
xlabel('Northing / km');
ylabel('Easting / km');
colormap gray
drawnow();

pause(1);
[S,R] = analyze_pattern(b,L,nb,'img/observed',meta,[],[],false,false);

% PACF and EACF
try
	figure(100);
	clf();
	disp('ar2-coeff')
	cc = ar2_acf2c(R.raw(2),R.raw(3))
	parcorr(b)
	sys = ar(b-mean(b),2);
	[num, den] = tfdata(sys);
	cc_ = den{1}; cc_ = cc_(2:3)';
	S_ = spectral_density_ar2(fx,[1,cc']);
	S_(:,2) = spectral_density_ar2(fx,[1,cc_']);
	figure(100);
	subplot(2,2,3);
	hold on;
	plot(fx,S_);
	
	%sys = arima(2,0,1);
	%sys = arima(3,0,2); sys_ = estimate(sys,c)
	%sys = arima([1 0 1],0,2);
	%sys = estimate(sys,b)
	sys = armax(b-mean(b),[1,2]);
	%pause
	
	R_ = real(ifft(S_));
	R_ = R_./R_(1,:);
	%z=zeros(length(x),1);
	%z(1)=1; R_=filter(1,[1,cc'],z);
	%R_(:,2)=filter(1,[1,cc_'],z);
	subplot(2,2,4);
	hold on;
	plot(x,R_)
	%R_(1:3) 
	
catch e
	e
end

if (pflag)
	sp = meta.plotscale;
	ar = meta.aspect;
	pdfprint(1,'img/observed-pattern-2d.pdf',sp-1);
end

end % analyze_pattern

