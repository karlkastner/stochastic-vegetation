Source code accompanying the manuscript titled "Irregularity of self-organized
vegetation patterns : Theory and empirical evidence", by Karl K\"astner et al.

It contains all files necessary to reproduce the values and figures in the 
manuscript and supplement. The processing is fully automatically after calling
the matlab script "vegetation_batch"

Dependencies:
	Matlab
	Python3
	QGIS plugin for Python3
	internet connection to fetch aerial images from the Google maps tile server

