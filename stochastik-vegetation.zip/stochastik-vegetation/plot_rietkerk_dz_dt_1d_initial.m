% Mon 31 May 20:20:46 CEST 2021
function b = plot_rietkerk_dz_dt_1d_initial(meta)
	if (nargin()<1)
		meta = vegetation_metadata();
	end
	pflag = meta.pflag;
	fflag = pflag;
	
	%[p,s] = rk.parameter();

	nsum = true;	
	Lw  = 1600/5;
	meta.L = 8000;
	L = meta.L;
	nbartlett = meta.nbartlett;
	nb = 5;
	Ti = meta.Ti;
	To = meta.To;
	dx = meta.dx;
	sd = meta.sd;
	%nx  = length(x);
	%x   = (0:dx:L-dx)';
%	rk  = Rietkerk('n',nx,'L',L);
%	rk.init();
%	dt  = 0.5*dx/rk.p.Dh;
	
	sda  = sd*sqrt(1/dx);
	nfa  = 0;
	nfh  = 0;
	rhoa = 0.499;
	%base  = sprintf(    'rietkerk1d-L-%g-dx-%g-Ti-%g-To-%g',round(L),dx,Ti,To);
	iname = sprintf('rietkerk1d-L-%g-dx-%g-Ti-%g',round(L),dx,Ti);
	ipath = ['mat/',iname,'.mat'];
	
	if (~exist(ipath,'file'))
		run_rietkerk_dz_dt_1d(meta);
	end
	load(ipath);

	x   = rk.x;
	fx  = fourier_axis(x);
	df  = fx(2)-fx(1);

	[b1,w,h] = rk.extract1(y(end-1,:)');
	[b,w,h] = rk.extract1(y(end,:)');
	ie = rk.infiltration_enhancement(b);
	printf('E[ie] = %f\n',mean(ie))
	printf('std(ie) = %f\n',std(ie))
	printf('s/mu = %f\n',std(ie)/mean(ie))

	splitfigure([2,2],[1e3,4],fflag);
	cla();
	plot(x,ie)
	ylim([0,max(ie)])
	title('infiltration enhancement')
	drawnow

	%basename = ['img/rietkerk1d-L-',num2str(L)];
	[S, R] = analyze_pattern(b,L,nb,['img/',iname],meta);

	if (pflag)
		L_str = num2str(L);
		a = meta.aspect;
		sp = meta.plotscale;
%		pdfprint(1e4+1,['img/rietkerk1d-unperturbed-biomass-L-',L_str],sp,a);
	end
end

