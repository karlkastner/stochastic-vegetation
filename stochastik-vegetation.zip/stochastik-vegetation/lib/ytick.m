function ytick(tick)
	set(gca,'ytick',tick)
end
