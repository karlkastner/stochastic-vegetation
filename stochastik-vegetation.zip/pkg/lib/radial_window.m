% 2021-12-22 13:30:25.176493233 +0100
function w = radial_window(r,rmax,order)
	if (nargin()<3)
		order =2;
	end
	switch (order)
	case{0}
		w = (r<=0.75*rmax);
	case {1}
		w    = min(1,max(2*(1-abs(r)./rmax),0));
	case {2}
		%w = (1/2)*(1 - cos(2*pi*r./rmax));
		w = (1/2)*(1 - cos(2*pi*r./rmax)).*(abs(r)./rmax<1);
		w(abs(r)/rmax<0.5) = 1;
	end % switch
end

