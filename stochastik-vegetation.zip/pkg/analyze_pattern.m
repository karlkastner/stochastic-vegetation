% Tue 20 Jul 23:47:34 CEST 2021
function [S,R,stat] = analyze_pattern(b,L,nb,basename,meta,Sref,rk,plotflag,normalize)
	if (nargin()<9)
		normalize = false;
	end
	correctlocalmean = true;
	method = 'ls';
	% levels for confidence intervals
	pp     = [0.16,0.84];

	stat   = struct();
	S      = struct();
	R      = struct();

	n  = length(b);
	x  = L*(0:n-1)'/n;
	fx = fourier_axis(L,n);
	df  = 1/L; 
	fdx = find(fx>=0);

	switch (normalize)
	case {0,false}
		% nothing to do
	case {true,1}
		b      = b-min(b);
		b      = b/rms(b);
	case {'detrend'}
		x = (1:n)';
		A = [ones(n,1),x];
		b_ = A \ b;
		b  = b - A*b_;
		b = b/rms(b);
	end
	b_     = b-mean(b);

	% periodogram
	S.raw  = periodogram(b_,L);
	S.raw0 = periodogram(b,L);

	% moments
	f_mu     = wmean(S.raw(fdx),fx(fdx));
	f_std	 = wstd(S.raw(fdx),fx(fdx));
	%q       = periodogram_quantiles(fx,S,p);
	%f_stdrel = wstd(S.raw(fdx),fx(fdx))/f_mu;
	%f_lstd   = wstd(S.raw(fdx),log(fx(fdx)));

	% determine number of segments for bartlett's estimate
	if (~isempty(nb))
		stat.m  = nb;
	else
		lseg    = 1./f_mu;
		stat.m  = round(sqrt(L./lseg));
	end	

	% non-parameteric densities
	S.bartlett    = periodogram_bartlett(b_,L,stat.m,n,[],correctlocalmean);
	S.filt = ifftshift(meanfilt1(fftshift(S.raw),stat.m));
	S.flat = spectral_density_flat(L,n);

	[stat.Sc.bartlett,mdx] = max(S.bartlett(fdx));
	stat.fc.bartlett = fx(fdx(mdx));
	[stat.Sc.filt,mdx] = max(S.filt(fdx));
	stat.fc.filt = fx(fdx(mdx));

	% reference density for confidence interval
	if (nargin()>5 && ~isempty(Sref))
		S.ref = Sref;
	else
		S.ref = S.bartlett;
	end
	[stat.Sc.ref,mdx] = max(S.ref);
	stat.fc.ref    = fx(mdx);

	% fit log normal density by method of moments
	[lmu,lsd]     = logn_moment2param(f_mu,f_std);
	S.lognormal   = lognpdf(fx,lmu,lsd);
	[fc_ln,Sc_ln] = logn_mode(lmu,lsd);
	S.lognormal   = S.lognormal/(sum(S.lognormal(fdx))*df);
	%[stat.Sc.lognormal,mdx]     = max(S.lognormal);
	%stat.wavelength.lognormal = 1./fx(mdx);
	stat.wavelength.lognormal = 1./fc_ln;
	stat.Sc.lognormal = Sc_ln;
	%[max(S.lognormal) Sc_ln]
	%[fc_ln fx(mdx)]

	% fitted parametric spectral densities
%	par0 = [0.5*f_mu,10];
	% TODO, no magic numbers
	par0 = [stat.fc.bartlett,50];
	% S.ref or S.raw?
	[par.bp, S.bandpass]   = fit_spectral_density(fx,S.raw,par0,L,'f','bandpass-continuous',method);
	[par.lo, S.lorentzian] = fit_spectral_density(fx,S.raw,par0,L,'f','lorentzian',method);
	[par.bm, S.brownian]   = fit_spectral_density(fx,S.raw,par.lo,L,'f','brownian-phase',method);
	%[par.bm, S.brownian]   = fit_spectral_density(fx,S.ref,par0,L,'f','brownian-phase',method);

	
	[stat.Sc.bandpass,mdx]   = max(S.bandpass);
	[stat.Sc.lorentzian,mdx] = max(S.lorentzian);
	[stat.Sc.brownian,mdx]   = max(S.brownian);

	% goodness of fit of parametric densities compared to non-parametric densities
	% TODO no magic numpers
	fdx_ = fx > 0 & fx < 4*f_mu;
%	transect_t.r2_bartlett(idx)   = 1 - mean((S.bartlett-S.bartlett(fdx_)).^2)./var(S.bartlett(fdx_));
	f_C = {'bandpass','lorentzian','brownian','lognormal'}
	var_ref   = var(S.ref(fdx_));
	for jdx=1:length(f_C)
		% the mse could be corrected (lowere) for uncertainty in bartlett's estiamte
		% we do not do this here, as this in extreme cases leads to
		% an R2 > 1
		stat.mse.(f_C{jdx})     = mean((S.(f_C{jdx})(fdx_)-S.ref(fdx_)).^2);
		stat.r2.(f_C{jdx})      = 1 - stat.mse.(f_C{jdx}) ./ var_ref;
	end

	S.c = periodogram_confidence_interval(pp,S.ref,1);

	try
		% TODO this range is a bit arbitrary
		% maybe 0.5 fc_bartlett  to f_mu ?
		fmin = f_mu/8;
		fmax = f_mu;
		[pe,ratio,maxShat,mdx_,fdx_,S.mue] = periodogram_test(fx,S.raw,fmin,fmax,'exclusive',stat.m);
		[pi,ratio,maxShat,mdx_,fdx_,S.mui] = periodogram_test(fx,S.raw,fmin,fmax,'inclusive',stat.m);
	catch e
		disp(e);
		pe = NaN;
		pi = NaN;
	end

	% correlogiram and autocorrelation
	R.raw     = autocorr_fft(cvec(b),[],1);
	R.b       = real(ifft(S.bartlett));
	R.b       = R.b/R.b(1);
	R.bp      = real(ifft(S.bandpass));
	R.bp      = R.bp./R.bp;
	R.ref     = real(ifft(S.ref));
	R.ref     = R.ref/R.ref(1);

	% stationarity test
	[ps,D,pp,ratio,mdx_] = periodogram_test_stationarity(b,stat.m);

	stat.fc.bandpass            = abs(par.bp(1));

	stat.biomass                = mean(b);
	stat.wavelength.mu          = 1./f_mu;
	stat.wavelength.bartlett    = 1./stat.fc.bartlett;
	stat.wavelength.bandpass    = 1./abs(par.bp(1));
	stat.wavelength.brownian    = 1./abs(par.bm(1));
	stat.wavelength.lorentzian  = 1./abs(par.lo(1));

	% moments of frequency distribution f=k/2pi
	template = 'raw';
	stat.f.mean                 = wmean(S.(template)(fdx),fx(fdx)); 
	stat.f.std                  = wstd(S.(template)(fdx),fx(fdx)); 
	stat.f.skew                 = wskew(S.(template)(fdx),fx(fdx)); 
	stat.f.kurt                 = wkurt(S.(template)(fdx),fx(fdx)); 

	stat.regularity.bandpass    = par.bp(2);
	stat.regularity.brownian    = abs(par.bm(2));
	stat.regularity.lorentzian  = abs(par.lo(2));
	stat.celerity               = [];
	stat.acf_decay_rate         = acf_decay_rate(x,R.ref);
	stat.p_periodic             = pe;

	[sd_omega,q]                = periodogram_std(fx,S.raw);

	% plots
	if (plotflag)

	printf('Periodogram Statistics\n');
	printf('max Sb %f\n',stat.Sc.bartlett); %*fx(mdx));
	printf('f_mean %f\n',f_mu);
	printf('f_std %f\n',stat.f.std);
	printf('sd_k %f\n',sd_omega);

	pi = 3.146;
	printf('k_c : %g\n',2*pi*par.lo(1));
	printf('lambda_c : %g\n',1/par.lo(1))
	printf('p : %g\n',par.lo(2));
	printf('p exclusive %f\n',pe);
	printf('p inclusive %f\n',pi);

	printf('stationarity test p : %f\n', ps);
	printf('stationarity test D : %f\n', D);

	
	fflag = meta.pflag;
	scale = stat.fc.ref;
	% pattern
	fdx = fx>=0;
	splitfigure([2,2],[1,1],fflag);
	cla();
	drawnow();
	fdx_ = scale*(x-x(1))<meta.pattern.xlim(2);
	b_ = b(fdx_);
	b_ = b_-min(b_);
	b_ = b_/rms(b_);
	plot(scale*x(fdx_),b_,'linewidth',1.5)
	xlim(meta.pattern.xlim);
	ylim([0,3.5]);
	set(gca,'ytick',meta.pattern.ytick);
	xlabel(meta.pattern.xlabel,'interpreter','latex');
	ylabel(meta.pattern.ylabel,'rot',0,'interpreter','latex');
	drawnow();

	% periodogram and density
	splitfigure([2,2],[1,2],fflag);
	cla();
	drawnow();
	if (pe == 0)
	stem(fx(fdx)/scale,df*S.raw(fdx),'-','linewidth',4,'marker','none');
	ylim([0, 1.05*max(df*S.raw(fdx))])
	else
	errorarea2(fx(fdx)/scale,scale*[S.c(fdx,1),zeros(size(S.c(fdx),1),1),S.c(fdx,2)],meta.areacol,'FaceAlpha',1)
	hold on;
	plot(fx(fdx)/scale,scale*S.raw(fdx),'k-','linewidth',1);
	plot(fx(fdx)/scale,scale*S.ref(fdx),'r','linewidth',1.5);
	ylim(meta.periodogram.ylim);
	end
	set(gca,'ytick',meta.periodogram.ytick);
	xlabel(meta.periodogram.xlabel,'interpreter','latex')
	ylabel(meta.periodogram.ylabel,'rot',0,'interpreter','latex');
	xlim(meta.periodogram.xlim)
	vline((1:10),'linestyle','--','color','k')
	drawnow();

	% autocorrelation
	splitfigure([2,2],[1,3],fflag);
	cla();
	drawnow();
if (0 == pe)
	R.rate = acf_decay_rate(x,R.raw)
	plot(x*scale, R.raw, 'linewidth',1.5);
	hold on;
	h = plot(x*scale,exp(-R.rate*x),'k--','linewidth',1.5);
else
	plot(x*scale,R.ref,'linewidth',1.5);
	hold on
	if (~isempty(stat.acf_decay_rate))
	h   = plot(x*scale,exp(-stat.acf_decay_rate*x),'k--','linewidth',1.5);
	end
end
	h.HandleVisibility = 'off';
	xlim(meta.acf.xlim);
	ylim(meta.acf.ylim);
	ytick(meta.acf.ytick);
	xlabel(meta.acf.xlabel,'interpreter','latex');
	ylabel(meta.acf.ylabel,'rot',0,'interpreter','latex');
	hline(0);
	drawnow()
	

	% QQ-plot
	fdx = (fx>=0);
	m = sum(fdx);
	pq = (1:m)'/(m+1);
	a = 1;                                                          
	b_ = (stat.m-1);                                                     
	qbeta = stat.m*betainv(pq,a,b_);
	d1 = 2;
	d2 = 2*(stat.m-1);
	qfisher = finv(pq,d1,d2);
	qchi2 = 1/2*chi2inv(pq,2);

	% note : for bartlett, the distribution is not beta,
	%        only close to beta for a small number of splits
	% the distribution is exactly beta for smoothing
	if (true) %nargin()<6)
		% empirical
		qref = qbeta;
		S.ref = S.bartlett;
		S.ref = S.filt;
		%S.ref = qfisher;
	else
		% exact
		qref = qchi2;
		S.ref = S.ref;
	end

	%figure(200)
	%clf();
	splitfigure([2,2],[2,1],fflag);
	cla();
	plot(pq,1/2*chi2inv(pq,2));
	hold on;
	plot(pq,sort(S.raw(fdx)./S.flat(fdx)));
	plot(pq,sort(S.raw(fdx)./S.bartlett(fdx)));
if (0)
	plot(pq,sort(S.raw(fdx)./S.mui(fdx)));
end
	
	splitfigure([2,2],[2,2],fflag);
	cla();
	h = plot([0,20],[0,20],'linewidth',0.5);
	h.HandleVisibility='off';
	hold on;
	plot(qchi2,sort(S.raw(fdx)./S.flat(fdx)),'.k','linewidth',1.5);
	leg_C = {'flat'};
	%plot(qbeta,sort(S.raw(fdx)./S.mui(fdx)),'.b','linewidth',1.5);
	plot(qref,sort(S.raw(fdx)./S.ref(fdx)),'.r','linewidth',1.5);
	leg_C{end+1} = 'empirical';
	if (0)
	plot(1/2*chi2inv(p,2),sort(S.raw(fdx)./S.f(fdx,2)),'.b','linewidth',1.5);
	leg_C{end+1} = {'lorentzian'};
	end
	xlabel('expected quantile');
	ylabel('sample quantile');
	axis(8*[0,1,0,1]);
	axis equal;
	axis square;
	legend(leg_C{:},'location','southeast');
	set(gca,'colororder',meta.colororder);
	
	% stationarity
	%figure(300);
	%clf
	nb=5;
	splitfigure([2,2],[2,3],fflag);
	cla
	try
		q = periodogram_qq(b,nb);
		plot(q(:,1),q(:,2),'.');
		hold on;
		mq=1.05*(max(q(:)));
		plot([0,mq],[0,mq],'k');
		axis square;
		axis([0,mq,0,mq])
		xlabel('expexcted')
		ylabel('sampled');
	catch e
		e
	end
	
	% average band shape
	splitfigure([2,2],[2,4],fflag);
	cla
	nf = 100;
	[y_mu,y_sd,yy] = correct_phase_3(b,nf);
	y_mu = circshift(y_mu,+15);
	y_mu = trifilt1([y_mu;y_mu;y_mu],21);
	y_mu = y_mu(nf+1:2*nf);
	y_mu = y_mu/rms(y_mu);
	n = length(y_mu);
	x = linspace(0,1,nf)';
	plot(x,y_mu,'linewidth',1.5);
	ylim([0,max(y_mu)*1.02])
	%xlabel(meta.pattern.xlabel);
	%ylabel(meta.pattern.ylabel);
	%plot(([circshift(y_sd./sqrt(size(yy,2)),+11),circshift(y_mu,+11)]./mean(y_mu)))
	
	% QQ
	if (meta.pflag)
		sp = meta.plotscale;
		ar = meta.aspect;
		pdfprint(11,[basename,'-pattern.pdf'],sp,ar);
		pdfprint(12,[basename,'-spectral-density.pdf'],sp,ar);
		pdfprint(13,[basename,'-autocorrelation.pdf'],sp,ar);
		pdfprint(22,[basename,'-qq.pdf'],sp,ar);
%	pdfprint(100,'img/observed-pattern-stationarity-qq.pdf',sp);
	%	pdfprint(24,[basename,'-shape.pdf'],sp);
	end
	end
end

