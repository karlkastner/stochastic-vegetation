% 2021-12-03 10:51:02.490036669 +0100

function plot_observed_pattner(meta)
if (nargin()<1)
	meta = vegetation_metadata();
end
%if (~exist('pflag','var'))
%	pflag = 0;
%end
fflag = meta.pflag;
pline = false;

rp = 50;
rmax = 80;
rp = 75;
nb = 12;

img=imread('img/2d/2/pattern_2d_+11.33202_+028.34331.png');
img = mean(img,3);
n = size(img);
n = min(n);
img = img(1:n,1:n);
n = [n,n];

img = img-min(img(:));
img = img/rms(img(:));
%img = img-mean(img(:));
x = (fourier_axis(sqrt(n(1)/n(2)),n(1)));
y = (fourier_axis(sqrt(n(2)/n(1)),n(2)));
fx = (fourier_axis(n(1),n(1)));
fy = (fourier_axis(n(2),n(2)));
r = hypot(x,y');
fr = hypot(fx,fy');
w = radial_window(r,rmax);

Shat  = abs(fft2(img-mean(img(:)))).^2;
R     = real(ifft2(Shat));
S     = real(fft2(w.*R));
Shat  = Shat./max(Shat(:));
R     = R./max(R(:));
S     = S./max(S(:));

x     = fftshift(x);
y     = fftshift(y);
r     = fftshift(r);
fr     = fftshift(fr);
R     = fftshift(R);
Shat  = fftshift(Shat);
S     = fftshift(S);

S_ = S;
S_(r<15)=0;
[val,mdx] = max(S_,[],'all');
[i,j] = ind2sub(n,mdx);

s  = 4;
xc = [n(1)/2+1, i];
yc = [n(2)/2+1, j];
xc  = xc(1) + [0, s*(xc(2)-xc(1))];
yc = yc(1) + [0, s*(yc(2)-yc(1))];
[xc,yc,cS] = improfile(S',round(xc),round(yc));
[xc,yc,cR] = improfile(R',round(xc),round(yc));
rc  = r(sub2ind(n,round(xc),round(yc)));
%fr  = fourier_axis(rc);
frc = fr(sub2ind(n,round(xc),round(yc)));

xc_ = [n(1)/2+1, i]
yc_ = [n(2)/2+1, j]
d   = [xc_(2)-xc_(1);
       yc_(2)-yc_(1)];

d = d./hypot(d(1),d(2));
if (0)
xc_ = [1,n(1)];
yc_ = xc_.*d(2)/d(1);
else
	yc_ = [1,n(2)];
	xc_ = -fliplr(yc_)*d(1)/d(2);
	xc_ = xc_-mean(xc_) + n(1)/2;
end


% transect and 1D estimates along transects
[xc_,yc_,cI] = improfile(img',round(xc_),round(yc_));
cI = cI-mean(cI);
rI = hypot(xc_-xc_(1),yc_-yc_(1));
f1D = fourier_axis(rI);
x1D = fourier_axis(rI);
R1D = autocorr_fft(cI);

dr  = (rI(end)-rI(1))/(length(rI)-1);
x1D = fourier_axis(dr,length(rI));
w1D = radial_window(x1D,rmax);

%S1D = periodogram_bartlett(cI,rI(end),nb,length(rI))
fdx = (f1D>=0) & (f1D<=frc(end));
%S1D(:,2) = S1D(:,1).^2;
S1D = ifft(w1D.*R1D);
S1D = S1D./mean(S1D(fdx,:));


%figure(1);
%clf
splitfigure([2,4],[1,1],fflag);
cla();
if (pline)
	surface(y,x,0.*img,img,'edgecolor','none')
else
	imagesc(y,x,img);
end
hold on
plot(y(round(yc_)),x(round(xc_)),'r','linewidth',1.5);
%plot3(y(round(yc_)),x(round(xc_)),255*ones(size(yc_)),'r','linewidth',1.5);
axis equal
axis ij 
axis tight
axis off
title('Pattern (biomass proxy)','interpreter','latex');
axis off

splitfigure([2,4],[1,2],fflag);
cla();
imagesc(x,y,Shat);
axis equal;
axis([-1,1,-1,1]*rp);
caxis([0,0.2]);
title('Periodogram $\hat S$','interpreter','latex')';
axis off;

splitfigure([2,4],[1,3],fflag);
cla();
if (pline)
surface(y,x,R,'edgecolor','none')
else
	imagesc(y,x,R);
end
hold on
%plot3(y(round(yc)),x(round(xc)),ones(size(yc)),'r','linewidth',1.5);
plot(y(round(yc)),x(round(xc)),'r','linewidth',1.5);
axis ij 
axis equal
axis square
axis([-1,1,-1,1]*rp);
title('Autocorrelation $\hat R$','interpreter','latex');
axis off

% estimate the spectral density by clipping
splitfigure([2,4],[1,4],fflag);
cla();
if (pline)
surface(y,x,S,'edgecolor','none')
else
	imagesc(y,x,S);
end
axis equal
axis square
axis([-1,1,-1,1]*rp);
axis ij
hold on 
%plot3(y(j),x(i),10,'r*')
%plot3(y(round(yc)),x(round(xc)),ones(size(yc)),'r','linewidth',1.5);
plot(y(round(yc)),x(round(xc)),'r','linewidth',1.5);
title('Spectral Density $\hat S$','interpreter','latex');
axis off

[~, mdx] = max(cS);
fc = frc(mdx);

splitfigure([2,4],[1,5],fflag);
cla();
plot(rI*fc,cI)
ylabel('b/rms(b) (Proxy)')
xlabel('$x/\lambda_c$','interpreter','latex');

splitfigure([2,4],[1,7],fflag);
cla();
plot(rc*fc,cR,'linewidth',1.5)
hold on;
plot(rI*fc,R1D,'linewidth',1.5);
%xlim([0,200*fc]);
xlim([0,fc*rmax]);
ylabel('$\hat R$','rot',0,'interpreter','latex');
legend('2D','1D');
xlabel('$x / \lambda_c$','interpreter','latex')

splitfigure([2,4],[1,8],fflag);
cla();
plot(frc/fc,cS/mean(cS),'linewidth',1.5)
hold on;
plot(f1D(fdx)/fc,S1D(fdx),'linewidth',1.5)
xlim([0,0.07/fc])
legend('2D','1D');%,'1D squared');
ylabel('S','rot',0);
xlabel('$k / k_c$','interpreter','latex');

if (meta.pflag)
	ps = 3;
	aspect = 4/3;
	pdfprint(11,'img/pattern-2d.pdf',ps,aspect,[]);
	pdfprint(12,'img/pattern-2d-periodogram.pdf',ps,aspect,[]);
	pdfprint(13,'img/pattern-2d-autocorrelation.pdf',ps,aspect,[]);
	pdfprint(14,'img/pattern-2d-spectral-density.pdf',ps,aspect,[]);
	pdfprint(15,'img/pattern-2d-transect.pdf',ps,aspect,[]);
	pdfprint(17,'img/pattern-2d-transect-autocorrelation.pdf',ps,aspect,[]);
	pdfprint(18,'img/pattern-2d-transect-spectral-density.pdf',ps,aspect,[]);
end

end % plot_observed_pattern

