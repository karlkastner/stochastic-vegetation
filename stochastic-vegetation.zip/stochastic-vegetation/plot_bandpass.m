% 2021-07-16 22:05:33.403410953 +0200

function plot_bandpass(meta)

	if(nargin()<1)
		meta = vegetation_metadata();
	end
	%pflag = meta.pflag;

	% for reproducibility, set initialize the randon number generator to the same state every time	
	rng(0);
	
	L   =  meta.example.L;
	dx  =  meta.example.dx;
	fc  =  meta.example.fc;
	Sc_fc  =  meta.example.Sc_fc;
	p   = sd_bandpass_continuous_max2par(fc,Sc_fc/fc);
	n   =  L/dx;
	m   =  1e4;
	pp  = [0.16,0.84];

	rho = filter_f0_to_rho(fc,dx);
	
	x  = linspace(0,L,n)';
	fx = fourier_axis(x);
	xx  = randn(n,m);
	fdx = fx>0;
	dx = x(2)-x(1);
	df = fx(2)-fx(1); 
	
	% test mean
	yy = bandpass1d_fft(xx,fc,p,dx);
	SS = periodogram(yy,L);
	S = struct();
	S.mu  = mean(SS,2);
	e  = zeros(n,1);
	e(n/2) = 1;
	y_bp   = bandpass1d_implicit(e,rho,p,true);
	%y_bp   = bandpass1d_fft(e,fc,p,dx);
	S.ir = periodogram(y_bp,L);
	S.bp = spectral_density_bandpass_discrete(fx,fc,p,dx,'f');
	S.bpc = spectral_density_bandpass_continuous(fx,fc,p);
	
	% test mean
	figure(1);
	clf
	subplot(2,2,1)
	plot(fx(fdx),[S.ir(fdx,:),S.mu(fdx,:),S.bp(fdx,:), S.bpc(fdx,:)]*fc);
	xlim([0,4*fc]);
	ylabel('Sc/lambda_c');
	legend('ir','empirical','analytical');
	pause(1)
	
	% test confidence intervals
	qS = quantile(SS,pp,2);
	Sc = periodogram_confidence_interval(pp,S.bp,1);
	subplot(2,2,2)
	plot(fx(fdx),[qS(fdx,:)],'k-');
	hold on
	plot(fx(fdx),[Sc(fdx,:)],'r--');
	xlim([0,4*fc]);
	
	pq = (1:n/2-1)'/(n/2+1-1);
	%Sm = 1/2*chi2_mean(2);
	q  = 1/2*chi2inv(pq,2);
	subplot(2,2,3)
	plot(q,sort(SS(fdx,1)./S.bp(fdx)))
	
	b = yy(:,1);
	%b = circshift(b,round(-3.5/60*length(b)));
	b = circshift(b,round(-52.3/fc/dx));
	
	% nb = 5
	tp = Pattern_Transect('b',b,'L',L,'S.true',S.bp,'opt.basename','img/bandpass');
	tp.analyze();
	tp.plot(meta);

	figure(3)
	clf
	plot(tp.fx,[tp.S.bartlett,tp.S.bandpass,tp.S.brownian])

	%figure(3)
	%clf
	%plot(x*fc,b)	
end % plot_bandpass

