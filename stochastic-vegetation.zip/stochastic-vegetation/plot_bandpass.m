% 2021-07-16 22:05:33.403410953 +0200

function plot_bandpass(meta)

if(nargin()<1)
	meta = vegetation_metadata();
end
%pflag = meta.pflag;

rng(0);

n = 1e4;
m = 1e2;
L = 2;

p  = 1;
%rho = 0.05^(1e2/n)
%fc = filter_rho_to_f0(rho,L/n)
fc = 23.7;
rho = filter_f0_to_rho(fc,L/n);

x  = linspace(-L/2,L/2,n)';
fx = fourier_axis(x);
xx  = randn(n,m);
fdx = fx>0;
dx = x(2)-x(1);
df = fx(2)-fx(1); 

% test mean
yy = bandpass1d_fft(xx,fc,p,dx);
SS = periodogram(yy,L);
S = struct();
S.mu  = mean(SS,2);
e  = zeros(n,1);
e(n/2) = 1;
y_bp   = bandpass1d_implicit(e,rho,p,true);
%y_bp   = bandpass1d_fft(e,fc,p,dx);
S.ir = periodogram(y_bp,L);
S.bp = spectral_density_bandpass_discrete(fx,fc,p,dx,'f');

% test mean
figure(1);
clf
subplot(2,2,1)
plot(fx(fdx),[S.ir(fdx,:),S.mu(fdx,:),S.bp(fdx,:)]);
xlim([0,4*fc]);
pause(1)

% test confidence intervals
pp = [0.16,0.84];
qS = quantile(SS,pp,2);
Sc = periodogram_confidence_interval(pp,S.bp,1);
subplot(2,2,2)
plot(fx(fdx),[qS(fdx,:)],'k-');
hold on
plot(fx(fdx),[Sc(fdx,:)],'r--');
xlim([0,4*fc]);

pq = (1:n/2-1)'/(n/2+1-1);
%Sm = 1/2*chi2_mean(2);
q  = 1/2*chi2inv(pq,2);
subplot(2,2,3)
plot(q,sort(SS(fdx,1)./S.bp(fdx)))



nb = 5;
b = yy(:,1);
b = circshift(b,round(-3.5/60*length(b)));
%S = spectral_density_bandpass_discrete(fx,fc,p,dx,'f');

[S,R] = analyze_pattern(b,L,nb,'img/bandpass',meta,S.bp,[],true,false);

end % plot_bandpass

