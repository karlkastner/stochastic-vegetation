% 2021-11-26 19:40:22.060116517 +0100

	pflag = false;
	addpath('lib');
	mkdir('mat/');

	meta = vegetation_metadata();
	meta.pflag = pflag;	
	close all;
	meta.periodogram.ytick = [0:0.25:10];
	system('LD_LIBRARY_PATH= python3 vegetation_transects_fetch.py');
	plot_rietkerk_dz_dt_1d_initial(meta);
	close all
	meta               = vegetation_metadata();
	meta.pflag         = pflag;	
	meta.acf.ytick     = [];
	meta.pattern.ytick = [];
	plot_observed_pattern(meta);
	close all;
	meta.periodogram.ytick = [];
	plot_bandpass(meta);
	close all;
	plot_brownian_phase(meta);
	close all;
	plot_rietkerk_dz_dt_1d(meta);
	vegetation_transects_analyze(meta);
	close all;
	vegetation_transects_plot(meta);
	rietkerk_1d_series(meta);
	close all;
	rietkerk_1d_series_plot(meta);
	system('LD_LIBRARY_PATH= python3 vegetation_patterns_fetch_2d.py')
	close all;
	plot_observed_pattern_2d();

