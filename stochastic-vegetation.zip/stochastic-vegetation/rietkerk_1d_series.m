% 2021-07-06 15:17:53.166366045
%function rkmap = rietkerk_1d_series(meta,rkmap)
function rietkerk_1d_series(meta)
	if (nargin()<1)
		meta = vegetation_metadata();
	end

	% TODO no magic filenames and numbers	
	oname    = 'mat/rietkerk-1d-series.csv';
	
	% standard deviation of heterogeneous infiltration coefficient
	sd_a = 0.00:0.01:0.20;
	% velocity of surface water
	vh   = [1:1:20];
	% diffusion of surface water
	eh   = [1];
	% fit frequency
	form = 'f';
	
	timer = tic();
	if (nargin()<2)
	%~exist('rkmap','var'))
		clear rk_a;
		clear stat
		rkmap = Rietkerk_Map('path_str','mat/');
		rkmap.init();
	
		bb   = [];
		aa   = [];
		cc   = [];
		ccme = [];
		for kdx=1:length(eh)
		for jdx=1:length(vh)
		for idx=1:length(sd_a)
			disp([idx,jdx,sd_a(idx),vh(jdx)]);
			%sd_a = sd_a(idx);
			%vh = vh(jdx);
			%eh = eh(kdx);
		
			param = {  'L', meta.mopt.L ...
				 ,'n', round(meta.mopt.L/meta.mopt.dx) ...
				 ,'T', meta.mopt.To ...
				 ,'nt', round(meta.mopt.To/meta.mopt.dt)  ...
				 ,'initial_condition', meta.mopt.initial_condition ...
			         ,'pss.a', sd_a(idx) ...
				 ,'pmu.eh' , eh(kdx) ...
				 ,'pmu.vh' , vh(jdx) ...
				};
		
			% run model
			[t,y,rk] = rkmap.run(param{:});
			rk_a(idx,jdx) = rk;
		 	toc(timer);
			a(:,idx,jdx)  = rk.p.a.*ones(length(rk.x),1);
			b             = rk.extract1(y);
			bb(:,idx,jdx) = b(end,:);
			yy(:,idx,jdx) = y(end,:);
	%		[c] = migration_celerity_1d(b,rk.dt,rk.dx);
			c = rk.celerity(double(y));
			% TODO no magic number
			cc(idx,jdx,1)  = mean(c(200:end));
		end % for idx
		end % for jdx
		end % for kdx
	end % if ~exist rtmap
	
	fx = fourier_axis(rk.x);

	tp = Pattern_Transect();	
	% extract properties of generated patterns
	for jdx=1:length(vh)
	for idx=1:length(sd_a)
		%basename  = [];
		Strue     = [];
		%plotflag  = false;
		%normalize = false;
	
		% number of slices for bartlett's estimate
		% nb = 10; 
		tp(idx,jdx) = Pattern_Transect('b',bb(:,idx,jdx),'L',rk.L,'S.true',Strue)
		tp(idx,jdx).analyze();
		tp(idx,jdx).stat.corr     = corr(a(:,idx,jdx),bb(:,idx,jdx));
		tp(idx,jdx).stat.celerity = cc(idx,jdx);
		%stat(idx,jdx) = tp.stat;
		%tp.plot(meta);
		% [S,R,stat(idx,jdx)] = analyze_pattern(bb(:,idx,jdx),rk.L,nb,basename,meta,Strue,rk_a(idx,jdx),plotflag,normalize);
	end % for idx
	end % for jdx
	
	tab = tp.tabulate();
	tab.sd_a                  = repmat(cvec(sd_a),1,length(vh));
	tab.vh                    = repmat(rvec(vh),length(sd_a),1);
	save('mat/rietker-1d-series.mat','tab','sd_a','vh');
	
	% write the table
	if (0)
	% this is not scalar any more and hence not a table any more
	% TODO write for vh = 10 or convert to single sheet
	writetable(tab,oname);
	copyfile(oname,[oname(1:end-4),'-',datestr(now(),'yyyy-mm-dd'),'.csv']);
	end
	
end % rietkerk_1d_series

