% 2021-07-06 15:17:53.166366045
%
% run a series of simulations with the heterogeneous Rietkerk model,
% varying the flow velocity vh and the infiltration coefficient a
%
% function rkmap = rietkerk_1d_series(meta,rkmap)
function rietkerk_1d_series(meta)
	if (nargin()<1)
		meta = vegetation_metadata();
	end

	% TODO no magic filenames and numbers	
	oname    = 'mat/rietkerk-1d-series.csv';
	
	% standard deviation of heterogeneous infiltration coefficient
	sd_a = meta.mopt.sd_a;
	% velocity of surface water
	vh   = meta.mopt.vh;
	% diffusion of surface water
	eh   = meta.mopt.eh;

	nx = round(meta.mopt.L/meta.mopt.dx);
	
	rkmap = Rietkerk_Map('path_str','mat/');
	rkmap.init();

	siz  = [length(sd_a),length(vh),length(eh)];
	aa   = zeros([nx,siz]);
	bb   = zeros([nx,siz]);
	cc   = zeros(siz);
	rk_a = repmat(Rietkerk(),siz);
	for kdx=1:length(eh)
	    for jdx=1:length(vh)
		y0 = 'random';
		for idx=1:length(sd_a)
			disp([idx,jdx,sd_a(idx),vh(jdx)]);
		
			param = {  'L', meta.mopt.L ...
				 ,'n', nx ...
				 ,'T', meta.mopt.To ...
				 ,'nt', round(meta.mopt.To/meta.mopt.dt)  ...
			         ,'pss.a', sd_a(idx) ...
				 ,'pmu.eh' , eh(kdx) ...
				 ,'pmu.vh' , vh(jdx) ...
				 ,'initial_condition', y0 ... % meta.mopt.initial_condition ...
				};

			if (idx == 1)
				% run model for the first time, with random conditions
				[t,y,rk]   = rkmap.run(param{:});
				y0         = rk.initial_condition_from_central_frequency(y);
				param{end}        = y0;
			end
			% run model
			[t,y,rk]          = rkmap.run(param{:});
			rk_a(idx,jdx,kdx) = rk;
			aa(:,idx,jdx,kdx) = rk.p.a.*ones(length(rk.x),1);
			b                 = rk.extract1(y);
			bb(:,idx,jdx,kdx) = b(end,:);
			c                 = rk.celerity(double(y));
			cc(idx,jdx,kdx)   = mean(c(round(end/2):end));
		end % for idx
	    end % for jdx
	end % for kdx
	
	tp = repmat(Pattern_Transect(),siz);
	% extract properties of generated patterns
	for kdx=1:length(eh)
	    for jdx=1:length(vh)
		for idx=1:length(sd_a)
			tp(idx,jdx,kdx) = Pattern_Transect('b',bb(:,idx,jdx),'L',rk.L ...
							, 'opt.normalize',false);
			tp(idx,jdx,kdx).analyze();
			tp(idx,jdx,kdx).stat.corr     = corr(aa(:,idx,jdx,kdx),bb(:,idx,jdx,kdx));
			tp(idx,jdx,kdx).stat.celerity = cc(idx,jdx,kdx);
		end % for idx
	    end % for jdx
	end % kdx	

	tab         = tp.tabulate();
	fx          = tp(1,1,1).fx;
	tab.sd_a    = repmat(cvec(sd_a),1,length(vh));
	tab.vh      = repmat(rvec(vh),length(sd_a),1);
	save('mat/rietkerk-1d-series.mat','tab','sd_a','vh','eh','tp');
	
	% write the table
	if (0)
	% this is not scalar any more and hence not a table any more
	% TODO write for vh = 10 or convert to single sheet
	writetable(tab,oname);
	copyfile(oname,[oname(1:end-4),'-',datestr(now(),'yyyy-mm-dd'),'.csv']);
	end
end % rietkerk_1d_series

