% Mon 31 May 20:20:46 CEST 2021
function meta = vegetation_metadata()
	meta.L   = 4*4e3; % 16*4e3
	meta.nbartlett = 5;
	meta.Ti  = 8e3;
	meta.dx  = 4; % 2
	% 7.5*meta.L
	meta.To  = 1e4; % 1e4
	meta.dt  = 20;
	meta.sd_a  = 0.05;
	meta.eh  = 1;

	meta.confidence_level = 0.05;
	meta.fitmethod = 'ls';
	meta.filename.patterns_sampled = 'mat/patterns-sampled.mat';

	% limits for testing patterns
	meta.pflag = false;
	meta.Lseg = 400;
	meta.fmin = 1/400;
	meta.fmax = 1/25;
	meta.colororder = [0,0,0; 0.9,0,0; 0,0.25,0.8];
	meta.areacol = [0.55,0.75,1];
	meta.aspect = 4/3;
	meta.plotscale = 4;
	meta.pattern.xlim = [0,3.5]; % 4.5
	meta.pattern.xlabel = '$x / \lambda_c$';
	meta.pattern.ylabel = '';
	meta.periodogram.xlim = [0,3.5]; % 4.5
	meta.periodogram.ylim = [0,2.8];
	meta.periodogram.ytick = [0:4];
	meta.acf.ytick = -0.5:0.5:1;
	meta.pattern.ytick = 0:4;
	meta.periodogram.xlabel = '$k / k_c$';
	meta.periodogram.ylabel = ''; %'$S \frac{k_\mu}{2 \pi}\;\;\;\;$',
	meta.acf.xlim = [0,1.5]; % 2.5
	meta.acf.ylim = [-0.5,1.05];
	meta.acf.xlabel = '$x / \lambda_c$';
	meta.acf.ylabel = '';

	meta.vh = [0,10,5,15];

	meta.nti = 1e2;
	meta.nto = 1e3;
	%meta.defaultflag = false; %true;
	meta.initial_condition = 'random';
end

