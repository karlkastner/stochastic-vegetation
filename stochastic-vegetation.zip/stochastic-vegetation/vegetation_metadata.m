% Mon 31 May 20:20:46 CEST 2021
%
% metadata for analysis and model runs of vegetation patterns
%
function meta = vegetation_metadata()

	meta.filename.patterns_sampled = 'mat/patterns-sampled.mat';
	
	% for example densities plots
	meta.example.L  = 8000;
	meta.example.fc = 0.01;
	meta.example.Sc_fc = 0.67;
	meta.example.dx = 1;
	meta.example.vh = 10;
	meta.example.sd_a = 0.11;
	meta.example.L_ = 16e3;

	% numerical model parameters
	meta.mopt.L    = 16e3; % 16*4e3
	meta.mopt.dx   = 4; % 2
	meta.mopt.Ti   = 8e3;
	meta.mopt.To   = 1e4; % 1e4
	meta.mopt.dt   = 20;
	meta.mopt.sd_a = 0.00:0.01:0.20; % 0.05
	meta.mopt.eh   = 1;
	meta.mopt.vh   = 1:1:20; %[0,10,5,15];
	meta.mopt.nti  = 1e2;
	meta.mopt.nto  = 1e3;

	% recommended geomean or median as these yield consistent results for wavelength and wavenumber(frequency),
	% 	i.e. geomean(wavelength) = 1/geomean(f_c)
	% (arithmetic)-mean and harmonic-mean do not yield consistent results:
	%	i.e. mean(wavelength) != 1/mean(f_c)
	meta.mfun  = @median;

	% plot options
	meta.pflag = false;
	meta.colororder = [0,0,0; 0.9,0,0; 0,0.25,0.8];
	meta.areacol = [0.55,0.75,1];
	meta.aspect = 4/3;
	meta.plotscale = 4;
	meta.pattern.xlim = [0,3.5]; % 4.5
	meta.pattern.xlabel = '$x / \lambda_c$';
	meta.pattern.ylabel = '';
	meta.periodogram.xlim = [0,3.5]; % 4.5
	meta.periodogram.ylim = [0,2.8];
	meta.periodogram.ytick = (0:4);
	meta.acf.ytick = -0.5:0.5:1;
	meta.pattern.ytick = 0:4;
	meta.periodogram.xlabel = '$k / k_c$';
	meta.periodogram.ylabel = ''; %'$S \frac{k_\mu}{2 \pi}\;\;\;\;$',
	meta.acf.xlim = [0,1.5]; % 2.5
	meta.acf.ylim = [-0.5,1.05];
	meta.acf.xlabel = '$x / \lambda_c$';
	meta.acf.ylabel = '';
end

