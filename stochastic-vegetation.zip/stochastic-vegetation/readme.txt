Source code accompanying the manuscript titled "Irregularity of self-organized
vegetation patterns : Theory and empirical evidence", by Karl K\"astner et al.

It contains all scripts necessary to reproduce the values and figures in the 
manuscript and supplement. The processing is fully automatically after calling
the Matlab script "vegetation_batch". An internet connection to fetch aerial
images from the Google maps tile server is required.

Dependencies:
	Matlab
	Python3
	QGIS plugin for Python3

