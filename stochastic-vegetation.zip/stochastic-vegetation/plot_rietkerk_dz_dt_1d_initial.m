% Mon 31 May 20:20:46 CEST 2021
function b = plot_rietkerk_dz_dt_1d_initial(meta)
	if (nargin()<1)
		meta = vegetation_metadata();
	end
	pflag = meta.pflag;
	fflag = pflag;
	
	nsum = true;	
	Lw  = 1600/5;
	meta.mopt.L = 8000;
	L = meta.example.L;
	dx = meta.example.dx;
	sd_a = meta.example.sd_a;
	vh   = meta.example.vh;

	base  = sprintf(    'rietkerk1d-L-%g-dx-%g-Ti-%g-To-%g' ...
				,round(L),dx,meta.mopt.Ti,meta.mopt.To);
	oname_ = base;

	rkmap = Rietkerk_Map('path_str','mat/');
	rkmap.init();

	param = {   'L', L, ...
		    'n', round(L/dx), ...
		    'T', meta.mopt.To, ...
		    'nt', round(meta.mopt.To/meta.mopt.dt), ...
		    'initial_condition', meta.mopt.initial_condition, ...
		    'pss.a',   sd_a, ...
		    'pmu.eh' , meta.mopt.eh, ...
		    'pmu.vh' , vh ...
		};

	% run model
	[t,y,rk] = rkmap.run(param{:});
	y = double(y);

	% TODO reintroduce second run with main wavelength only
	
	x   = rk.x;
	fx  = fourier_axis(x);
	df  = fx(2)-fx(1);

	[b1,w,h] = rk.extract1(y(end-1,:)');
	[b,w,h] = rk.extract1(y(end,:)');
	ie = rk.infiltration_enhancement(b);
	printf('E[ie] = %f\n',mean(ie))
	printf('std(ie) = %f\n',std(ie))
	printf('s/mu = %f\n',std(ie)/mean(ie))

	splitfigure([2,2],[1e3,4],fflag);
	cla();
	plot(x,ie)
	ylim([0,max(ie)])
	title('infiltration enhancement')
	drawnow

	tp = Pattern_Transect('b',b,'L',L,'opt.basename',['img/',oname_]);
	tp.analyze();
	tp.plot(meta);

	if (pflag)
		L_str = num2str(L);
		a = meta.aspect;
		sp = meta.plotscale;
%		pdfprint(1e4+1,['img/rietkerk1d-unperturbed-biomass-L-',L_str],sp,a);
	end
end  % plot_rietkerk_dzdt_1d_initial

