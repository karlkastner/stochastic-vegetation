% Mon 31 May 20:20:46 CEST 2021
%
% plot a stochastic pattern generate with the heterogeneous Rietkerk model
%
function bb = plot_rietkerk_dz_dt_1d(meta)
	if (nargin()<1)
		meta = vegetation_metadata();
	end
	pflag = meta.pflag;
	fflag = pflag;

	sd_a = [0,meta.example.sd_a];
	vh   = meta.example.vh;

	L    = meta.example.L;
	dx   = meta.example.dx;

	% plot option
	Lw   = 1600/5;

	figure(1);
	clf();
	figure(2);
	clf();

	y0 = 'random';
	for idx=1:length(sd_a)
	
	base  = sprintf('rietkerk1d-L-%g-dx-%g-Ti-%g-To-%g-sd_a-%g' ...
				,L,dx,meta.mopt.Ti,meta.mopt.To,sd_a(idx));
	oname_ = base;

	rkmap = Rietkerk_Map('path_str','mat/');
	rkmap.init();

	param = {   'L', L, ...
		    'n', round(L/dx), ...
		    'T', meta.mopt.To, ...
		    'nt', round(meta.mopt.To/meta.mopt.dt), ...
		    'pss.a',   sd_a(idx), ...
		    'pmu.eh' , meta.mopt.eh, ...
		    'pmu.vh' , vh ...
		    'initial_condition', y0 ...
		};

	if (idx == 1)
		% run model for the first time, with random conditions
		[t,y,rk]   = rkmap.run(param{:});
		y0 = rk.initial_condition_from_central_frequency(y);
		%[b,w,h]    = rk.extract1(y(end,:));
		%% determine dominant wave-length
		%S          = periodogram_bartlett(b-mean(b),rk.L,round(sqrt(rk.n)),rk.n); 
		%[Smax,mdx] = max(S);
		%fx = fourier_axis(rk.x);
		%fc = fx(mdx);
		%% round to nearest integer
		%fc = round(rk.L*fc)/rk.L;
		%b  = mean(b) + std(b)*sqrt(2)*(cos(2*pi*fc*cvec(rk.x)));
		%w  = repmat(mean(w),rk.n,1);
		%h  = repmat(mean(h),rk.n,1);
		%y0 = double([b;h;w]);
		param{end} = y0;
	end
	
	% run model
	[t,y,rk] = rkmap.run(param{:});
	y = double(y);

	x  = rk.x;
	fx = fourier_axis(x);

	[b,w,h] = rk.extract1(y);
	bb(:,:,idx) = b;
	
	figure(1e3)
	subplot(2,3,idx)
	imagesc(b)
	if (idx==2)
	subplot(2,3,3)
	imagesc(b-bb(:,:,1));
	end
	subplot(2,2,idx+2)
	thresh = graythresh(b);
	b_=imbinarize(b,thresh);
	imagesc(b_)
	
	
	rms_b = rms(b(end,:));
	b_    = b-mean(b,2);
	b_    = b_(round(end/2):end,:);
	SS    = periodogram(b_.',L)';
	S     = mean(SS,1);
	fdx = fx>0;
	f_mu  = wmean(S(fdx),fx(fdx));
	printf('f_mu %f\n',f_mu);
	printf('lambda_mu %f\n',1/f_mu);
	S     = S/sum(S);

	splitfigure([2,3],[10,1],fflag);

	plot(x*f_mu,b(end,:)/rms_b,'linewidth',1.5);
	xlabel('x/\lambda_\mu');
	ylabel('$\displaystyle \frac{b}{\textrm{rms}(b)}\;\;\;\;$' ...
					,'rot',0,'interpreter','latex');
	hold on

	splitfigure([2,2],[10,2],fflag);
	plot(x,w(end,:))
	hold on
	xlabel('x');
	ylabel('w');

	splitfigure([2,3],[10,3],fflag);
	plot(x,h(end,:))
	hold on
	xlabel('x');
	ylabel('h');

	splitfigure([2,3],[10,4],fflag);
	plot(t,b(:,round(end/2)));
	hold on
	xlabel('t');
	ylabel('b');

	splitfigure([2,3],[10,5],fflag);
	plot(t,w(:,round(end/2)))
	hold on
	xlabel('t');
	ylabel('w');

	splitfigure([2,3],[10,6],fflag);
	plot(t,h(:,round(end/2)))
	hold on
	xlabel('t');
	ylabel('h');
	
	splitfigure([2,2],[20,1],fflag);
	plot(fx/f_mu,S*f_mu);
	hold on
	xlabel('$k / k_\mu$','interpreter','latex');
	ylabel('$S \frac{k_\mu}{2 \pi}$','interpreter','latex');

	pt = Pattern_Transect('b',b(end,:)','L',L,'opt.basename',['img/',oname_], ...
							'opt.normalize',false);
	pt.analyze();
	if (2 == idx)
		pt.plot(meta);
	end
	
	splitfigure([2,2],[3,2],fflag);
	%w = tukeywin(length(t));
	%w = w/sum(w);
	%b_ = b(:,round(end/2));
	%b_ = b_-mean(b_);
	
	plot(fx,pt.S.bartlett);
	hold on
	
	splitfigure([2,2],[3,3],fflag);
	b_ = b(end,:);
	a = autocorr_fft(b_,[],true);
	plot(x,a);
	hold on
	xlim([0,Lw*3]); ylim([-1,1])
	
	splitfigure([2,2],[3,4],fflag);
	b_ = b(:,round(end/2));
	a = autocorr_fft(b_,[],true);
	plot(t,a);
	hold on
	c0 = 0.2;
	xlim([0,Lw*3/abs(c0(1))]); ylim([-1,1])
	
	end
	
	%figure(3);
	%clf();
	splitfigure([2,2],[4,1],fflag);
	if (1==idx)
		cla;
	end
	% TODO lowpass-filtered
	d = bb - mean(bb,2);
	d = mean(d(:,:,1).*d(:,:,2),2);
	s1 = std(bb(:,:,1),[],2);
	s2 = std(bb(:,:,2),[],2);
	% TODO, no magic numbers
	Tp = 1980;
	plot(t/Tp,d./(s1.*s2),'linewidth',1.5);
	ylabel('r_b^2','rot',0);
	xlabel('$t \frac{\lambda}{c}$','interpreter','latex');
	xlim([0,10e3/Tp]);
	hline(0)

	splitfigure([2,2],[4,2],fflag);
	nf = 100;
	ls = {'-','--'};
	for jdx=1:2
	c = [];
	for idx=1:2
		b_ = bb(:,:,idx);
		if (jdx>1 && nf>1)
			b_ = trifilt1(b_,11);
			b_ = trifilt1(b_',11)';
		end
		dt = t(2)-t(1);
		%dx = dx;
		c(:,idx) = migration_celerity_1d(b_,dt,dx);
	end
	plot(mid(t),c,ls{jdx});
	hold on
	col={'k','r'};
	mc=median(c);
	for idx=1:2
	hline(mc(idx),'color',col{idx})
	end
	set(gca,'colororderindex',1)
	end
	
	ylabel('c');
	
	%d1 = rms(flat(diff(bb(:,:,1),[],1)));
	%d2 = rms(flat(diff(bb(:,:,1),[],2)));
	%d1/d2

	splitfigure([2,2],[4,3],fflag);
	b1 = bb(:,:,1);
	b2 = bb(:,:,2);
	b1 = b1 - mean(b1,2);
	b2 = b2 - mean(b2,2);
	c = mean(b1.*b2,2)./(std(b1,[],2).*std(b2,[],2));
	plot(t,c);
	xlabel('t');
	ylabel('c');
	
	splitfigure([2,2],[4,4],fflag);
	for idx=1:2
	S    = periodogram(bb(:,:,idx),L);
	maxS = max(S,[],2);
	maxS = meanfilt1(maxS,10);
	plot(t,maxS);
	hold on
	end
	xlabel('t');
	ylabel('max S')

	figure(100);
	clf();
	%nf = 41;
	for idx=1:2
	b=bb(end-10,:,idx)';
	b=b-mean(b);
	subplot(2,2,idx);
	f = fft(b);
	if (idx==1)
		fdx = abs(f).^2 > 1e-3*sum(abs(f).^2);
		f2 = abs(f).^2;
	else
		f2 = abs(f).^2;
		fdx = 1:length(f);
	end
	stem(fx(fdx),2*(f2(fdx))/sum(abs(f)).^2);
	yyaxis right
	a = angle(f(fdx));
	a = wrapToPi(a);
	plot(fx(fdx),(a/pi),'r*')
	ylim([-1,1]);
	ylabel('\phi/\pi');
	xlim([0,0.07]);

	a=angle(fft(bb(:,:,idx)));
	subplot(2,2,2+idx);
	da = diff(a(:,fdx),[],2);
	da(:,end+1) = NaN;
	da = wrapToPi(da);
	plot(fx(fdx),da(end-10:end,:));
	end

for jdx=1:2
	figure(100+jdx);
	clf();
	%nf = 71;
	for idx=1:9
	b=squeeze(bb(end-idx+1,:,jdx))';
	f = fft(b);
	if (jdx==1)
		gdx = abs(f).^2 > 1e-3*sum(abs(f).^2);
		fdx = 1:size(b,1);
		fdx1=find(fdx);
		%f = trifilt1(f,nf);
	else
		fdx = 1:size(b,1);
	end
	subplot(3,3,idx);

if (0)
	a = angle(f(fdx));
	plot(fx(fdx),(a/pi),'k*')
	yyaxis right
	hold on
	plot(fx(gdx),da(gdx)/pi,'r*')

end
if (0)
	b=bb(end-idx+(0:1),:,jdx);
	f = fft(b').';
if (1)
	a = angle(f);
	da = diff(a);
else
	df = diff(f./abs(f));
	da = angle(df);
end
	da = wrapTo2Pi(da);
end
	plot(fx(fdx),da(fdx)/pi,'*-')
	hold on
	plot(fx(gdx),da(gdx)/pi,'r*')
	end
end
	figure(103);
	clf();
	for idx=1:2
	[a,da_dt] = determine_phase_shift1(bb(round(end/2)+1:end,:,idx),1);
	subplot(2,2,1)
	plot(a);
	hold on
	vline(fdx1);
	subplot(2,2,2)
	plot(da_dt);
	hold on
	
	end
	
	if (pflag)
		pdfprint(31,['img/',base,'-decorrelation.pdf'],2.5);
		ps = meta.plotscale;
		a = meta.aspect;
		pdfprint(41,['img/',base,'-biomass.pdf'],ps,a);
		pdfprint(42,['img/',base,'-spectral-density.pdf'],ps,a);
		pdfprint(43,['img/',base,'-autocorrelation.pdf'],ps,a);
	end
end

