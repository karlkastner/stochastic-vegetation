% 2021-09-10 12:23:20.262151784 +0200

function transect_t = vegetation_transects_analyze(meta,transect_t)
if (nargin()<1)
	meta = vegetation_metadata();
end
%if (~exist('pflag','var'))
%	pflag = 0;
%end
fflag      = meta.pflag;
plot_individual = false;
printscale = 3.5;
mfun = @median;

linear = false;
ksdensity_ = true;
ellipse_ = false;

r2_min = 0.5;
nrow   = 10;
ncol   = 10;

marker = 'o^v<>d*';
cm     = colormap('lines');
ne = 100;

normalize          = true;
nb                 = [];

% only compute statistics once and reuse on next call of script
if (nargin()<2)
	transect_t = table();
	clear stat
	
	% load sampled transects
	l          = load(meta.filename.patterns_sampled);
	transect_C = l.transect_C;
	nt         = length(transect_C);
	region     = l.continent;
	transect_t.length_m  = cvec(double(l.length));
	if (iscell(region))
		transect_t.region = region;
	else
		transect_t.region = mat2cell(region,ones(nt,1));
	end
	figmax        = ceil(nt/(nrow*ncol));
	
	% table with regional stationstics
	region_t = table(unique(transect_t.region,'rows','stable'),'VariableNames',{'Name'});
	nr       = length(region_t.Name);
	region_t.Name{end+1} = 'All';
	region_id     = NaN(nt,1);
	
	% assign region id to each transect
	for idx=1:nr
		region_id(strcmpi(transect_t.region,region_t.Name{idx}))=idx;
	end % for idx
	ns = zeros(nr,1);
	
	if (plot_individual)
	for idx=1:3
		for jdx=1:figmax
		figure(idx*100 + jdx)
		clf();
		end % for jdx
	end % for idx
	end % if plot_individual
	
	% compute individual pattern statistic
	for idx=1:nt
		fprintf('Pattern %d\n',idx)
	
		% proxy biomass by darkness of pixel value
		b = -transect_C{idx};	
	
		transect_t.N(idx,1) = length(b);
	
		[S,R_,stat(idx,1)] = analyze_pattern(b,transect_t.length_m(idx),nb,[],meta,[],[],false,normalize);
	
		if (plot_individual)
			x        = ((1:transect_t.N(idx))-0.5)'/transect_t.N(idx)*transect_t.length_m(idx);
			fx       = fourier_axis(x);
			fdx      = find(fx>0);
			df       = fx(2)-fx(1);
	
			set(groot,'CurrentFigure',100+floor(idx/(nrow*ncol))+1);
			subplot(nrow,ncol,mod(idx-1,nrow*ncol)+1)
			cla;
			plot(x,c);
			title(idx);
		
			set(groot,'CurrentFigure',200+floor(idx/(nrow*ncol))+1);
			subplot(nrow,ncol,mod(idx-1,nrow*ncol)+1)
			cla();
			fdx = fx>0;
			%plot(1e3*fx,S{:,1},'.');
			plot(1e3*fx(fdx),S.bartlett(fdx),'linewidth',1.5);
			hold on
			plot(1e3*fx(fdx),S.bandpass(fdx),'linewidth',1.5);
			plot(1e3*fx(fdx),S.lorentzian(fdx),'linewidth',1.5);
			plot(1e3*fx(fdx),S.lognormal(fdx),'linewidth',1.5);
			%vline(1e3*fc(idx,4),'color','b')
			xlim([0,50])
			hold on
			%plot(1e3*fx,S.std,'--r')
			if (1==idx)
				legend(S.Properties.VariableNames);	
			end	
			title(idx);
		
			set(groot,'CurrentFigure',300+floor(idx/(nrow*ncol))+1);
			subplot(nrow,ncol,mod(idx-1,nrow*ncol)+1)
			m = length(fdx);
			M(idx) = m;
			s = 1/2*chi2inv((1-[0.3,0.2,0.1,0.05]).^(1/m),2);
			%[sum(S.raw(fdx)>S.bartlett(fdx)*s)]
			plot(fx(fdx),S.raw(fdx)./S.bartlett(fdx))%, S.med(fdx)]);
		end % if plot_individual
	end % for idx
	drawnow();
end % if r
	
% retabulate
transect_t.mseg                  = arrayfun(@(x) x.m, stat);
transect_t.f_mean                = arrayfun(@(x) x.f.mean, stat);
transect_t.f_std                 = arrayfun(@(x) x.f.std, stat);
transect_t.f_skew                = arrayfun(@(x) x.f.skew, stat);
transect_t.f_kurt                = arrayfun(@(x) x.f.kurt, stat);
transect_t.fc_filt               = arrayfun(@(x) x.fc.filt, stat);
transect_t.fc_bartlett           = 1./arrayfun(@(x) x.wavelength.bartlett, stat);
transect_t.fc_bandpass           = 1./arrayfun(@(x) x.wavelength.bandpass, stat);
transect_t.fc_brownian           = 1./arrayfun(@(x) x.wavelength.brownian, stat);
transect_t.fc_lorentzian         = 1./arrayfun(@(x) x.wavelength.lorentzian, stat);
transect_t.fc_lognormal          = 1./arrayfun(@(x) x.wavelength.lognormal, stat);
transect_t.p_periodic            = arrayfun(@(x) x.p_periodic, stat);
transect_t.regularity_bandpass   = arrayfun(@(x) x.regularity.bandpass, stat);
transect_t.regularity_brownian   = arrayfun(@(x) x.regularity.brownian, stat);
transect_t.regularity_lorentzian = arrayfun(@(x) x.regularity.lorentzian, stat);
transect_t.r2_bandpass           = arrayfun(@(x) x.r2.bandpass, stat);
transect_t.r2_brownian           = arrayfun(@(x) x.r2.brownian, stat);
transect_t.r2_lorentzian         = arrayfun(@(x) x.r2.lorentzian, stat);
transect_t.Sc_bartlett           = arrayfun(@(x) x.Sc.bartlett, stat);
transect_t.Sc_bandpass           = arrayfun(@(x) x.Sc.bandpass, stat);
transect_t.Sc_brownian           = arrayfun(@(x) x.Sc.brownian, stat);
transect_t.Sc_lorentzian         = arrayfun(@(x) x.Sc.lorentzian, stat);
transect_t.Sc_lognormal          = arrayfun(@(x) x.Sc.lognormal, stat);

% discard bad patterns
% (transect_t.fc_lorentzian<frat_min*transect_t.f_mean) ...
bad = ( ... 
	  (transect_t.r2_lorentzian(:,end)<r2_min) ...
	| (transect_t.r2_brownian(:,end)<r2_min) ...
      ) ;
transect_t.good = ~bad;
transect_t.isperiodic     = (transect_t.p_periodic<meta.confidence_level);

% write analysis result to shapefile
shp                           = Shp.read('dat/vegetation-patterns-lines-merged.shp');
mydeal                        = @(x) deal(x{:});
[shp.length_m]                = mydeal(num2cell(transect_t.length_m));
[shp.region]                  = mydeal(transect_t.region);
[shp.isgood]                  = mydeal(num2cell(double(transect_t.good)));
[shp.isperiodic]              = mydeal(num2cell(double(transect_t.isperiodic)));
[shp.p_periodic]              = mydeal(num2cell(double(transect_t.p_periodic)));
%[shp.regularity_bandpass]     = mydeal(num2cell(transect_t.regularity_bandpass));
%[shp.regularity_brownian]     = mydeal(num2cell(transect_t.regularity_brownian));
%[shp.regularity_lorentzian]   = mydeal(num2cell(transect_t.regularity_lorentzian));
[shp.r2_bandpass]             = mydeal(num2cell(transect_t.r2_bandpass));
[shp.r2_brownian]             = mydeal(num2cell(transect_t.r2_bandpass));
[shp.r2_lorentzian]           = mydeal(num2cell(transect_t.r2_lorentzian));
[shp.Sc_bartlett]             = mydeal(num2cell(transect_t.Sc_bartlett));
[shp.Sc_bandpass]             = mydeal(num2cell(transect_t.Sc_bandpass));
[shp.Sc_brownian]             = mydeal(num2cell(transect_t.Sc_brownian));
[shp.Sc_lorentzian]           = mydeal(num2cell(transect_t.Sc_lorentzian));
[shp.wavelength_mean]         = mydeal(num2cell(1./transect_t.f_mean(:,1)));
[shp.wavelength_c_bartlett]   = mydeal(num2cell(1./transect_t.fc_bartlett));
[shp.wavelength_c_bandpass]   = mydeal(num2cell(1./transect_t.fc_bandpass));
[shp.wavelength_c_brownian]   = mydeal(num2cell(1./transect_t.fc_brownian));
[shp.wavelength_c_lorentzian] = mydeal(num2cell(1./transect_t.fc_lorentzian));

% limit, note that realmax = DBL_MAX results in an invalid shapefile
mymax = 9999;
[shp.wavelength_c_lorentzian] = mydeal(num2cell(min(mymax,[shp.wavelength_c_lorentzian])));
fdx = ~isfinite([shp.r2_lorentzian]);
[shp(fdx).r2_lorentzian] = deal(0);
Shp.write(shp,'dat/vegetation-patterns-lines-analyzed.shp');

bad = (transect_t.fc_lorentzian<0.1*transect_t.f_mean) | (transect_t.r2_lorentzian(:,end)<r2_min);
transect_t.good = ~bad;
 
% regionally averaged statistics
for idx=1:nr+1
	if (nr+1==idx)
		id = transect_t.good;
		%transect_t.region = {'all'};
	else
		id = (region_id == idx) & transect_t.good;
		%transect_t.region(idx) = {region_t.nameunique(idx-1,:)};
	end
	region_t.x(idx)           = mfun(flat(l.xy(id,1:2)));
	region_t.y(idx)           = mfun(flat(l.xy(id,3:4)));
	region_t.N(idx)           = length(transect_t.N(id));
	region_t.p_periodic(idx)  = mfun(transect_t.p_periodic(id));
	region_t.N_periodic(idx)  = sum(transect_t.isperiodic(id));
	region_t.pc_periodic(idx) = 100*sum(transect_t.isperiodic(id))/region_t.N(idx);
	region_t.lc_ba(idx)       = 1./mfun(transect_t.fc_bartlett(id));
	region_t.wavelength_mu(idx) = 1./mfun(transect_t.f_mean(id));
	region_t.rsd_f(idx)        = mfun(transect_t.f_std(id)./transect_t.f_mean(id));
	region_t.sk_f(idx)         = mfun(transect_t.f_skew(id));
	region_t.ku_f(idx)         = mfun(transect_t.f_kurt(id));
	%region_t.wavelength_c_lognormal   = 1./mean(fc.lognormal);
	%region_t.R2_lognormal         = mean(R2.(template)(:,4));
	region_t.lc_bandpass(idx)     = 1./mfun(transect_t.fc_bandpass(id));
	region_t.regularity_bandpass(idx)= mfun(transect_t.regularity_bandpass(id));
	region_t.r2_bandpass(idx)     = mfun(transect_t.r2_bandpass(id));
	region_t.lc_lorentzian(idx)     = 1./mfun(transect_t.fc_lorentzian(id));
	region_t.p_lo(idx)      = mfun(transect_t.regularity_lorentzian(id));
	region_t.r2_lorentzian(idx)     = mfun(transect_t.r2_lorentzian(id));
	region_t.dx(idx)        = mfun(transect_t.length_m(id)./transect_t.N(id));
	region_t.mseg(idx)         = mfun(transect_t.mseg(id));
 	region_t.corr_lkc_lp(idx) = corr(log(transect_t.fc_lorentzian(id)),log(transect_t.regularity_lorentzian(id)),'type','pearson');
 	region_t.corr_lkc_lp_bp(idx) = corr(log(transect_t.fc_bandpass(id)),log(transect_t.regularity_bandpass(id)),'type','pearson');
	region_t.corr_fc_L(idx)   = corr(log(transect_t.fc_lorentzian(id)),log(transect_t.length_m(id)));
	region_t.corr_fc_p(idx)   = corr(log(transect_t.regularity_lorentzian(id)),log(transect_t.length_m(id)));
end
disp(region_t)
writetable(region_t,'dat/vegetation-pattern-regions.csv');

% goodness of fit
splitfigure([2,3],[11,4],fflag);
cla();
plot(sort([transect_t.r2_bandpass,transect_t.r2_lorentzian,transect_t.r2_brownian]),'*');
ylabel('R^2');
drawnow

% density parameters
sub = {'BP','L','BM','LN','B'};
for gdx=1:5
for rdx=1:2

splitfigure([2,5],[10,5*(rdx-1)+gdx],fflag);
cla();
drawnow()

switch(gdx)
case {1}
x = transect_t.fc_bandpass;
if (rdx==1)
	y = transect_t.regularity_bandpass;
else
	y = transect_t.Sc_bandpass.*transect_t.fc_bandpass;
end
case {2}
x = transect_t.fc_lorentzian;
if (rdx==1)
	y = transect_t.regularity_lorentzian;
else
	y = transect_t.Sc_lorentzian.*transect_t.fc_lorentzian;
end
case {3}
x = transect_t.fc_brownian;
if (rdx==1)
	y = transect_t.regularity_brownian;
else
	y = transect_t.Sc_brownian.*transect_t.fc_brownian;
end
case {4}
x = transect_t.fc_lognormal;
if (rdx==1)
	continue;
	%y = NaN(size(x));
	%transect_t.regularity_lognormal;
else
	y = transect_t.Sc_lognormal.*transect_t.fc_lognormal;
end
case {5}
x = transect_t.fc_bartlett;
if (rdx==1)
	continue;
	%y = transect_t.regularity_bartlett;
	y = NaN(size(x));
else
	y = transect_t.Sc_bartlett.*transect_t.fc_bartlett;
end
end

n = 100;
if(linear)
	xx = linspace(0,1/20,n);
	xxf = xx;
else
	xf   = log10(x);
	xxf = linspace(-4,0,n);
	xx  = 10.^xxf; 
end
if (linear)
	yy = linspace(0,4,n);
	yyf = yy;
else
	yf  = log10(y);
	yyf = linspace(-1,0.75,n);
	yy = 10.^yyf;
end
[xxf,yyf] = meshgrid(xxf,yyf);
[xx,yy]   = meshgrid(xx,yy);
xyf       = [flat(xxf),flat(yyf)];
xy        = [flat(xx),flat(yy)];
lmu       = [];
mu        = [];
p_in_ellipse = [];
for idx=1:nr
	id=(region_id==idx) & transect_t.good;
	lmu(idx,:) = mean([xf(id),yf(id)]);
	%lmu(idx,:) = median([xf(id),yf(id)]);
	if (ksdensity_)
		f = mvksdensity([xf(id),yf(id)],xyf);
		[f_max,mdx] = max(f);
		mu(idx,1:2) = [xx(mdx),yy(mdx)];
		f = reshape(f,n,n);
		%xyf(mdx,:);
		fi = interp2(xxf,yyf,f,xf(id),yf(id),'linear');
		% int_0^r0 2pi r normpdf(r)*normpdf(0) dr = 0.68
		c = 0.32;
		pks(idx,gdx) = mean(fi > f_max*c);
	else
		mu(idx,:) = 10.^lmu(idx,:);
	end
	if (0)
		plot(xf(id),yf(id),marker(idx),'linewidth',1,'markersize',4,...
				'markerfacecolor',cm(idx,:),'color',cm(idx,:));
		hold on;
	end
	if (1)
		% plot central properties for each region
		h = plot(mu(idx,1),mu(idx,2),marker(idx),'markersize',5,'linewidth',2,'markerfacecolor',cm(idx,:),'color',cm(idx,:));
		%set(h,'HandleVisibility','off')
		hold on;
	end
	if (ksdensity_)
		% kernel density for each region
		[c,fh] = contour(xx,yy,f,[f_max*c,inf], ...
					'linewidth',1.5,'linecolor',cm(idx,:));
		fh.LineWidth = 2;
		set(fh,'HandleVisibility','off');
	end
	if (ellipse_)
		% covariance-ellipse for each region
		C  = cov([xf(id),yf(id)]);
		%c = 1;
		c  = [C(1),C(2),C(4),lmu(idx,1),lmu(idx,2)];
		ci = 0.68;
		[X, Y,v,e] = ellipse(c,ci,ne);
		h = plot(10.^X,10.^Y,'-','linewidth',2,'color',cm(idx,:));
		set(h,'HandleVisibility','off');
		xf_ = xf(id) - lmu(idx,1);
		yf_ = yf(id) - lmu(idx,2);
		xyf_ = sqrt(e) \ ([xf_,yf_]*v)'; %*inv(sqrt(e));
		p_in_ellipse(idx) = mean(hypot(xyf_(:,1),xyf_(:,2))<1);
	end
end % for idx
disp('p in ellipse')
disp(p_in_ellipse)
if (0)
	% kernel density for whole world
	f      = mvksdensity([x(good),par.lo(good,2)],xy);
	gray   = [0.5,0.5,0.5];
	[c,fh] = contour(xx,yy,reshape(f,n,n),[max(f(:))/normpdf(0)*normpdf(1),inf],'linewidth',1.5,'linecolor',gray);
end
	legend(region_t.Name{1:nr},'location','southeast','NumColumns',2);
	xlabel('$k_c \frac{\textrm{m}}{2 \pi}$','interpreter','latex');
	ylabel(['$p_{',sub{gdx},'}$'],'interpreter','latex','rot',0);
if (1)
	set(gca,'xscale','log')
 	set(gca,'yscale','log');
	xlim(10.^[-2.6,-0.5]);
	ylim([0.125,4]);
 	set(gca,'ytick',2.^(-3:3));
end

switch(gdx)
case{3}
	xlim(10.^[-3.5,-0.25]);
	ylim(2.^[-2,2.5])
end
if (2 == rdx)
	if (ksdensity_)
		%ylim(2.^[-2,0]);
		ylim(2.^[-2.25,0.25])
		xlim(10.^[-2.5,-0.25])		
	else
		set(gca,'xlim',10.^[-3.5,-0.125],'ylim',[1/64,4],'ytick',2.^(-5:2))
		set(gca,'ytick',roundn(10.^[-1.5:0.5:1],2));
	end
	%ylabel('$\displaystyle S_c \frac{k_c}{2 \pi}$','interpreter','latex');
	ylabel('$\displaystyle \frac{S_c}{\lambda_c}$','interpreter','latex');
end

% add second x-axis on top with wavelength
if (1)
	ax(1)=gca;
	xl=ax(1).XLim;
	ax(2)=axes('position',get(ax(1),'position'),'color','none','XAxisLocation','top');
	ax(2).XLim=xl;
	ax(2).YTick = [];
	tick = fliplr(2.^(0:10));
	ax(2).XTick = 1./tick;
	ax(2).XTickLabel = num2str(cvec(tick));
	set(ax,'box','off');
	xlabel(ax(2),'$\lambda_c$ / m','interpreter','latex')
	set(ax(2),'xscale','log');
	ax(1).Box = 'off';
	ax(2).XMinorTick = 'off';
	ax(2).XLim=xl;
end
drawnow();
end % for rdx
end % for gdx

splitfigure([2,3],[11,5],fflag);
cla();
plot(transect_t.fc_lorentzian,transect_t.length_m,'o');

if (meta.pflag)
	s = 0.95;
	s = 1;
	%pdfprint(102,'img/pattern-kc-vs-p-lorentzian',printscale,[],[],0.95);
	%pdfprint(104,'img/pattern-kc-vs-p-bandpass',printscale,[],[],0.95);
	pdfprint(108,'img/pattern-kc-vs-Sc-brownian',printscale,[],[],s);
end

end % function vegetation_transect_analyze

