% 2021-09-10 12:23:20.262151784 +0200
% Karl Kastner, Berlin
%
% analyze remotely sensed vegetation patterns
%
function vegetation_transects_analyze(meta)
	if (nargin()<1)
		meta = vegetation_metadata();
	end

	mfun       = meta.mfun;
	% TODO no magic options
	% plot options
	plot_individual = false;
	nrow       = 10;
	ncol       = 10;
	% TODO no magic filenames
	oname_mat = 'mat/vegetation-transects-analyzed.mat';
	iname_shp = 'dat/vegetation-patterns-lines-merged.shp';
	oname_shp = 'dat/vegetation-patterns-lines-analyzed.shp';

	% load sampled transects
	load_      = load(meta.filename.patterns_sampled);
	transect_C = load_.transect_C;
	nt         = length(transect_C);
	region     = load_.continent;
	length_m   = cvec(double(load_.length));
	if (~iscell(region))
		region = mat2cell(region,ones(nt,1));
	end
	
	% table with regional stationstics
	region_t = table(unique(region,'rows','stable'),'VariableNames',{'Name'});
	nr       = length(region_t.Name);
	region_t.Name{end+1} = 'All';
	region_id = NaN(nt,1);
	
	% assign region id to each transect
	for idx=1:nr
		region_id(strcmpi(region,region_t.Name{idx}))=idx;
	end % for idx
	
	if (plot_individual)
	figmax        = ceil(nt/(nrow*ncol));
	for idx=1:3
		for jdx=1:figmax
		figure(idx*100 + jdx)
		clf();
		end % for jdx
	end % for idx
	end % if plot_individual
	
	% compute individual pattern statistic
	tp=repmat(Pattern_Transect(),nt,1);
	ns  = 1000;
	L   = 50;
	fxi = fourier_axis(L,ns)'; 
	S   = struct();
	S.raw       = zeros(ns,nt);
	S.raw0      = zeros(ns,nt);
	S.bartlett0 = zeros(ns,nt);
	for idx=1:nt
		fprintf('Pattern %d\n',idx)
		% proxy biomass by darkness of pixel value
		b = -transect_C{idx};	
	
		tp(idx,1) = Pattern_Transect('b',b,'L',length_m(idx));
		tp(idx).analyze();
	
		[fx]          = tp(idx).fx;
		msk = (fx ~= 0); % explicitely exclude 0, as the mean has been subtracted
		S.raw(:,idx)       = interp1(fx(msk)/tp(idx).stat.f.mean0,tp(idx).S.raw(msk),fxi,'linear');
		S.raw0(:,idx)      = interp1(fx(msk)/tp(idx).stat.f.mean0,tp(idx).S.raw0(msk),fxi,'linear');
		S.bartlett0(:,idx) = interp1(fx(msk)/tp(idx).stat.f.mean0,tp(idx).S.bartlett0(msk),fxi,'linear');		

		% TODO merge with transect.plot	
		if (plot_individual)
			x = tp(idx).x;
			[fx,fdx] = tp(idx).fx;
			df       = tp(idx).df;
	
			set(groot,'CurrentFigure',100+floor(idx/(nrow*ncol))+1);
			subplot(nrow,ncol,mod(idx-1,nrow*ncol)+1)
			cla;
			plot(x,c);
			title(idx);
		
			set(groot,'CurrentFigure',200+floor(idx/(nrow*ncol))+1);
			subplot(nrow,ncol,mod(idx-1,nrow*ncol)+1)
			cla();
			fdx = fx>0;
			%plot(1e3*fx,S{:,1},'.');
			plot(1e3*fx(fdx),S.bartlett(fdx),'linewidth',1.5);
			hold on
			plot(1e3*fx(fdx),S.bandpass(fdx),'linewidth',1.5);
			plot(1e3*fx(fdx),S.lorentzian(fdx),'linewidth',1.5);
			plot(1e3*fx(fdx),S.lognormal(fdx),'linewidth',1.5);
			%vline(1e3*fc(idx,4),'color','b')
			xlim([0,50])
			hold on
			%plot(1e3*fx,S.std,'--r')
			if (1==idx)
				legend(S.Properties.VariableNames);	
			end	
			title(idx);
		
			set(groot,'CurrentFigure',300+floor(idx/(nrow*ncol))+1);
			subplot(nrow,ncol,mod(idx-1,nrow*ncol)+1)
			m = length(fdx);
			M(idx) = m;
			s = 1/2*chi2inv((1-[0.3,0.2,0.1,0.05]).^(1/m),2);
			%[sum(S.raw(fdx)>S.bartlett(fdx)*s)]
			plot(fx(fdx),S.raw(fdx)./S.bartlett(fdx))%, S.med(fdx)]);
			%drawnow();
		end % if plot_individual
	end % for idx
	fz = (fxi == 0);
	S.raw0(fz,:)      = 0;
	S.bartlett0(fz,:) = 0;
	
	transect_t = tp.tabulate();	
	transect_t.region    = region;
	transect_t.region_id = region_id;

	% write analysis result to shapefile

	shp                           = Shp.read(iname_shp);
	mydeal                        = @(x) deal(x{:});
	[shp.length_m]                = mydeal(num2cell(transect_t.length_m));
	[shp.region]                  = mydeal(transect_t.region);
	[shp.good_bandpass]           = mydeal(num2cell(double(transect_t.good.bandpass)));
	[shp.good_brownian]           = mydeal(num2cell(double(transect_t.good.brownian)));
	[shp.good_lognormal]          = mydeal(num2cell(double(transect_t.good.lognormal)));
	[shp.good_lorentzian]         = mydeal(num2cell(double(transect_t.good.lorentzian)));
	[shp.periodic]                = mydeal(num2cell(double(transect_t.periodic)));
	[shp.p_periodic]              = mydeal(num2cell(double(transect_t.p_periodic)));
	[shp.r2_bandpass]             = mydeal(num2cell(transect_t.r2.bandpass));
	[shp.r2_brownian]             = mydeal(num2cell(transect_t.r2.brownian));
	[shp.r2_lognormal]            = mydeal(num2cell(transect_t.r2.lognormal));
	[shp.r2_lorentzian]           = mydeal(num2cell(transect_t.r2.lorentzian));
	[shp.Sc_bandpass]             = mydeal(num2cell(transect_t.Sc.bandpass));
	[shp.Sc_bartlett]             = mydeal(num2cell(transect_t.Sc.bartlett));
	[shp.Sc_brownian]             = mydeal(num2cell(transect_t.Sc.brownian));
	[shp.Sc_lognormal]            = mydeal(num2cell(transect_t.Sc.lognormal));
	[shp.Sc_lorentzian]           = mydeal(num2cell(transect_t.Sc.lorentzian));
	[shp.wavelength_mean]         = mydeal(num2cell(1./transect_t.f.mean(:,1)));
	%[shp.f_mean0]                 = mydeal(num2cell(transect_t.f_mean0(:,1)));
	[shp.wavelength_c_bartlett]   = mydeal(num2cell(transect_t.wavelength.bartlett));
	[shp.wavelength_c_bandpass]   = mydeal(num2cell(transect_t.wavelength.bandpass));
	[shp.wavelength_c_brownian]   = mydeal(num2cell(transect_t.wavelength.brownian));
	[shp.wavelength_c_lognormal]  = mydeal(num2cell(transect_t.wavelength.lognormal));
	[shp.wavelength_c_lorentzian] = mydeal(num2cell(transect_t.wavelength.lorentzian));
	
	% limit, note that realmax = DBL_MAX results in an invalid shapefile
	mymax = realmax('single');
	[shp.wavelength_c_bartlett] = mydeal(num2cell(min(mymax,[shp.wavelength_c_bartlett])));
	[shp.wavelength_c_brownian] = mydeal(num2cell(min(mymax,[shp.wavelength_c_brownian])));
	[shp.wavelength_c_lorentzian] = mydeal(num2cell(min(mymax,[shp.wavelength_c_lorentzian])));
	fdx   = ~isfinite([shp.r2_lorentzian]);
	[shp(fdx).r2_lorentzian] = deal(0);
	Shp.write(shp,oname_shp);
 
	% regionally averaged statistics
	for idx=1:nr+1
		%if (nr+1==idx)
			%id = transect_t.good;
			%transect_t.region = {'all'};
		%else
		id = (transect_t.region_id == idx | (nr+1 == idx));
		%transect_t.region(idx) = {region_t.nameunique(idx-1,:)};
		%end
		region_t.x(idx)              = mfun(flat(load_.xy(id,1:2)));
		region_t.y(idx)              = mfun(flat(load_.xy(id,3:4)));
		region_t.nt(idx)              = sum(id);
		region_t.p_periodic(idx)     = mfun(transect_t.p_periodic(id));
		region_t.n_periodic(idx)     = sum(transect_t.periodic(id));
		region_t.pc_periodic(idx)    = 100*sum(transect_t.periodic(id))/region_t.nt(idx);
		region_t.wavelength_mu(idx)  = 1./mfun(transect_t.f.mean(id));
		region_t.rsd_f(idx)          = mfun(transect_t.f.std(id)./transect_t.f.mean(id));
		region_t.sk_f(idx)           = mfun(transect_t.f.skew(id));
		region_t.ku_f(idx)           = mfun(transect_t.f.kurt(id));
		region_t.dx(idx)             = mfun(transect_t.length_m(id)./transect_t.nx(id));
		region_t.mseg(idx)           = mfun(transect_t.mseg(id));

		region_t.lc_bartlett(idx)    = mfun(transect_t.wavelength.bartlett(id));
		region_t.Sc_lc_bartlett(idx) = mfun(transect_t.Sc.bartlett(id)./transect_t.wavelength.bartlett(id));

		% do not include bad samples from r2 averages
		region_t.r2_bandpass(idx)    = mfun(transect_t.r2.bandpass(id));
		region_t.r2_brownian(idx)    = mfun(transect_t.r2.brownian(id));
		region_t.r2_lognormal(idx)   = mfun(transect_t.r2.lognormal(id));
		region_t.r2_lorentzian(idx)  = mfun(transect_t.r2.lorentzian(id));
	
		id = (transect_t.region_id == idx | (nr+1)==idx) & transect_t.good.bandpass;
		region_t.lc_bandpass(idx)    = mfun(transect_t.wavelength.bandpass(id));
		region_t.Sc_lc_bandpass(idx) = mfun(transect_t.Sc.bandpass(id)./transect_t.wavelength.bandpass(id));
		region_t.ngood_bandpass(idx) = sum(id);

		id = (transect_t.region_id == idx | (nr+1) == idx) & transect_t.good.brownian;
		region_t.lc_brownian(idx)    = mfun(transect_t.wavelength.brownian(id));
		region_t.Sc_lc_brownian(idx) = mfun(transect_t.Sc.brownian(id)./transect_t.wavelength.brownian(id));
		region_t.ngood_brownian(idx) = sum(id);

		id = (transect_t.region_id == idx | (nr+1) == idx) & transect_t.good.lognormal;
		region_t.lc_lognormal(idx)  = mfun(transect_t.wavelength.lognormal(id));
		region_t.Sc_lc_lognormal(idx) = mfun(transect_t.Sc.lognormal(id)./transect_t.wavelength.lognormal(id));
		region_t.ngood_lognormal(idx) = sum(id);
	
		id = (transect_t.region_id == idx | (nr+1) == idx) & transect_t.good.lorentzian;
		region_t.lc_lorentzian(idx)  = mfun(transect_t.wavelength.lorentzian(id));
		region_t.Sc_lc_lorentzian(idx) = mfun(transect_t.Sc.lorentzian(id)./transect_t.wavelength.lorentzian(id));
		region_t.ngood_lorentzian(idx) = sum(id);
	end % for each region
	save(oname_mat,'transect_t','region_t','fxi','S');
	disp(region_t);
	writetable(region_t,'dat/vegetation-pattern-regions.csv');
end % function vegetation_transects_analyze

