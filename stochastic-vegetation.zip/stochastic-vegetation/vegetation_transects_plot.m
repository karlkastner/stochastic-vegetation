% 2021-09-10 12:23:20.262151784 +0200
% Karl Kastner, Berlin
%
% plot characteristics of remotely sensed vegetation patterns
%
function vegetation_transects_plot(meta)
	if (nargin()<1)
		meta = vegetation_metadata();
	end

	fflag      = meta.pflag;
	printscale = 3.5;
	
	% plot options
	plot_scale = 'logarithmic';
	marker     = 'o^v<>d*';
	cm         = colormap('lines');
	ne         = 100;
	nsurf      = 100;

	% TODO no magic filenames
	load('mat/vegetation-transects-analyzed.mat','transect_t','region_t','fxi','S');
	nr       = length(region_t.Name)-1; % exclude world
	
	% goodness of fit
	splitfigure([2,3],[12,1],fflag);
	cla();
	plot(sort([  transect_t.r2.bandpass ...
		   , transect_t.r2.lorentzian ...
		   , transect_t.r2.brownian ...
                  ]),'*');
	ylabel('R^2');
	drawnow();
	
	% plot bivariate density of density parameters
	sub     = {'BP','L','BM','LN','BL'};
	model_C = {'bandpass','lorentzian','brownian','lognormal','bartlett'};
	% 1 : kernel-density, 2 : variance-ellipse
	for kdx=1:2
	% for each density models
	for gdx=1:length(model_C)
		model = model_C{gdx};
		good = transect_t.good.(model);
	% 1 : parameter, 2 : density maximum
	for rdx=1:2
	
	splitfigure([2,5],[9+kdx,5*(rdx-1)+gdx],fflag);
	cla();
	drawnow();

	x = 1./transect_t.wavelength.(model);
	if (rdx==1)
		if (~strcmp(model,'lognormal') && ~strcmp(model,'bartlett'))
			y = transect_t.par2.(model);
		else
			continue;
		end
	else
		y = transect_t.Sc.(model)./transect_t.wavelength.(model);
	end
	
	switch (plot_scale)
	case {'linear'}
		xx = linspace(0,1/20,nsurf);
		xxf = xx;
		yy = linspace(0,4,nsurf);
		yyf = yy;
	case {'logarithmic'}
		xf   = log10(x);
		xxf = linspace(-4,0,nsurf);
		xx  = 10.^xxf; 
		yf  = log10(y);
		yyf = linspace(-1,0.75,nsurf);
		yy = 10.^yyf;
	end
	[xxf,yyf] = meshgrid(xxf,yyf);
	[xx,yy]   = meshgrid(xx,yy);
	xyf       = [flat(xxf),flat(yyf)];
	%xy        = [flat(xx),flat(yy)];
	lmu       = [];
	mu        = [];
	p_in_ellipse = zeros(nr,length(model_C));
	p_in_kd      = zeros(nr,length(model_C));
	lmu = zeros(nr,2);
	mu = zeros(nr,2);
	for idx=1:nr
		id=(transect_t.region_id==idx) & good;
		lmu(idx,:) = mean([xf(id),yf(id)]);
		%lmu(idx,:) = median([xf(id),yf(id)]);
		if (1 == kdx)
			f = mvksdensity([xf(id),yf(id)],xyf);
			[f_max,mdx] = max(f);
			mu(idx,1:2) = [xx(mdx),yy(mdx)];
			f = reshape(f,nsurf,nsurf);
			%xyf(mdx,:);
			fi = interp2(xxf,yyf,f,xf(id),yf(id),'linear');
			% int_0^r0 2pi r normpdf(r)*normpdf(0) dr = 0.68
			c = 0.32;
			p_in_kd(idx,gdx) = mean(fi > f_max*c);
			if (2 == rdx)
				disp(['ksdensity maxima of',region_t.Name{idx},' ',model]);
				printf('wavelength     : %g\n',1/mu(idx,1));
				printf('S_c / lambda_c : %g\n',mu(idx,2)*mu(idx,1));
			end
		else
			mu(idx,:) = 10.^lmu(idx,:);
		end
		if (0)
			plot(xf(id),yf(id),marker(idx),'linewidth',1,'markersize',4,...
					'markerfacecolor',cm(idx,:),'color',cm(idx,:));
			hold on;
		end
		if (1)
			% plot central properties for each region
			h = plot(mu(idx,1),mu(idx,2),marker(idx),'markersize',5,'linewidth',2,'markerfacecolor',cm(idx,:),'color',cm(idx,:));
			%set(h,'HandleVisibility','off')
			hold on;
		end
		if (1 == kdx)
			% kernel density for each region
			[c,fh] = contour(xx,yy,f,[f_max*c,inf], ...
						'linewidth',1.5,'linecolor',cm(idx,:));
			fh.LineWidth = 2;
			set(fh,'HandleVisibility','off');
		else
			% covariance-ellipse for each region
			C  = cov([xf(id),yf(id)]);
			%c = 1;
			c  = [C(1),C(2),C(4),lmu(idx,1),lmu(idx,2)];
			ci = 0.68;
			[X, Y,v,e] = ellipse(c,ci,ne);
			h = plot(10.^X,10.^Y,'-','linewidth',2,'color',cm(idx,:));
			set(h,'HandleVisibility','off');
			xf_ = xf(id) - lmu(idx,1);
			yf_ = yf(id) - lmu(idx,2);
			xyf_ = sqrt(e) \ ([xf_,yf_]*v)'; %*inv(sqrt(e));
			p_in_ellipse(idx,gdx) = mean(hypot(xyf_(:,1),xyf_(:,2))<1);
		end
	end % for idx
	if (0)
		% kernel density for whole world
		f      = mvksdensity([x(good),par.lo(good,2)],xy);
		gray   = [0.5,0.5,0.5];
		[c,fh] = contour(xx,yy,reshape(f,n,n),[max(f(:))/normpdf(0)*normpdf(1),inf],'linewidth',1.5,'linecolor',gray);
	end
		legend(region_t.Name{1:nr},'location','southeast','NumColumns',2);
		xlabel('$k_c \frac{\textrm{m}}{2 \pi}$','interpreter','latex');
		ylabel(['$p_{',sub{gdx},'}$'],'interpreter','latex','rot',0);
	if (1)
		set(gca,'xscale','log')
	 	set(gca,'yscale','log');
		xlim(10.^[-2.6,-0.5]);
		ylim([0.125,4]);
	 	set(gca,'ytick',2.^(-3:3));
	end
	
	switch(gdx)
	case{3}
		xlim(10.^[-3.5,-0.25]);
		ylim(2.^[-2,2.5])
	end
	if (2 == rdx)
		if (1 == kdx)
			xlim(10.^[-2.75,-0.25])		
			ylim(2.^[-2.7,0.75])
			%ylim(2.^[-2.25,0.5])
		else
			xlim(10.^[-3.5,-0.125]);
			ylim([1/64,4]);
			%set(gca,'ytick',2.^(-5:2))
			set(gca,'ytick',roundn(10.^(-1.5:0.5:1),2));
		end
		%ylabel('$\displaystyle S_c \frac{k_c}{2 \pi}$','interpreter','latex');
		ylabel('$\displaystyle \frac{S_c}{\lambda_c}$','interpreter','latex');
	end
	
	% add second x-axis on top with wavelength
	if (1)
		ax(1)=gca;
		xl=ax(1).XLim;
		ax(2)=axes('position',get(ax(1),'position'),'color','none','XAxisLocation','top');
		ax(2).XLim=xl;
		ax(2).YTick = [];
		tick = fliplr(2.^(0:10));
		ax(2).XTick = 1./tick;
		ax(2).XTickLabel = num2str(cvec(tick));
		set(ax,'box','off');
		xlabel(ax(2),'$\lambda_c$ / m','interpreter','latex')
		set(ax(2),'xscale','log');
		ax(1).Box = 'off';
		ax(2).XMinorTick = 'off';
		ax(2).XLim=xl;
	end
	drawnow();
	end % for rdx
	end % for gdx
	disp('p in ellipse')
	disp(p_in_ellipse);
	disp('p in kd');
	disp(p_in_kd);
	end % for kdx
	
	splitfigure([2,3],[12,2],fflag);
	cla();
	plot(transect_t.wavelength.lorentzian,transect_t.length_m,'o');

	figure(1e3)
	clf();
	model_C = {'bandpass','brownian','lognormal'};
	m = length(model_C);
	for idx=1:m
		model = model_C{idx};
		good = transect_t.good.(model) & transect_t.good.bartlett;

		subplot(2,m,idx)
		plot(transect_t.wavelength.bartlett,transect_t.wavelength.(model),'.');
		c = kendall_to_pearson(corr(transect_t.wavelength.bartlett(good),transect_t.wavelength.(model)(good),'type','kendall'));
		ratio = median((transect_t.wavelength.(model)(good)-transect_t.wavelength.bartlett(good))./transect_t.wavelength.bartlett(good));
		title(sprintf('corr^2 %0.2g, (l_model-lb)/l_bartlett = %0.2g',c.^2,ratio));
		xlim([0,200]); ylim([0,200]),
		hold on; plot([0,200],[0,200],'r')

		subplot(2,m,idx+m)
		plot((transect_t.Sc.bartlett(good)./transect_t.wavelength.bartlett(good)),(transect_t.Sc.(model)(good)./transect_t.wavelength.(model)(good)),'.')
		c = kendall_to_pearson(corr(transect_t.Sc.bartlett(good)./transect_t.wavelength.bartlett(good), ...
					transect_t.Sc.(model)(good)./transect_t.wavelength.(model)(good),'type','kendall'));
		ratio = median(((transect_t.Sc.(model)(good)./transect_t.wavelength.(model)(good)) ...
				-(transect_t.Sc.bartlett(good)./transect_t.wavelength.bartlett(good))) ...
				./ (transect_t.Sc.bartlett(good)./transect_t.wavelength.bartlett(good)));
		title(sprintf('corr^2 %0.2g, ((Sc/l)_model-Sc/l_b)/(Sc/l)_bartlett = %0.2g',c.^2,ratio));
		%median((transect_t.Sc.brownian./transect_t.wavelength.brownian)./(transect_t.Sc.bartlett./transect_t.wavelength.bartlett))
		hold on; plot([0,1.5],[0,1.5],'r')
	end

	figure(2e3);
	S_ = nanmedian(S.raw0,2);
	S_ = nanmean(S.raw0,2);
	S_=S_/spectral_density_area(fxi,S_);
	msk = fxi>0.1;
	df=fxi(2)-fxi(1);
	fmin = 1/8;
	fmax = 2;
	[par, Sfit] = fit_spectral_density(cvec(fxi),S_,[0.5,2],1/df,'f','brownian-phase','ls',fmin,fmax);
	fc = par(1); 
	[par, Sfit(:,2)] = fit_spectral_density(cvec(fxi),S_,[0.5,1],1/df,'f','bandpass-continuous','ls',fmin,fmax);
	fdx = fxi>0;
	clf();
	plot(fxi(fdx)/fc,fc*[S_(fdx),Sfit(fdx,:)],'linewidth',1.5);
	xlim([0, 5]);
	ylim([0, 1.05*max(fc*S_(fdx))]);
	vline(fmin/fc);
	xlabel('$k/k_c$','interpreter','latex');
	ylabel('$\frac{S_c}{\lambda_c}$','rot',0,'interpreter','latex');
	legend('$\hat S$','$S_{BM}$','$S_{BP}$','interpreter','latex');

	figure(3e3);
	r = transect_t.Sc.bartlett ./ transect_t.wavelength.bartlett;
	% r=transect_t.f_std.*transect_t.wavelength.bartlett;
	%r = S.raw0(2,:)';
	q = [0,quantile(r,[1/3,2/3]),inf];
	%fdx=r<median(r);
	S_ = [];
	for idx=1:3
	fdx = r>=q(idx) & r<=q(idx+1);
	S_(:,idx) = nanmean(S.raw0(:,fdx),2);
	end
	%S_=[nanmean(S.raw0(:,fdx),2),nanmean(S.raw0(:,~fdx),2)];
	S_ = S_./spectral_density_area(fxi,S_);
	S__ = S_;
	S__(fxi<1/8,:) = NaN;
	[mv,mdx] = max(S__);
	fc = fxi(mdx);
	%fc = 1;
	fdx= fxi>0;
	plot(cvec(fxi(fdx))./fc,S_(fdx,:).*fc,'linewidth',1.5);
	xlim([0,3.5]);
	h = legend('low','intermediate','high');
	title(h,'$S_c/\lambda_c$','interpreter','latex')
	xlabel('$k/k_c$','interpreter','latex');
	ylabel('$\frac{S_c}{\lambda_c}$','rot',0,'interpreter','latex');

	
	if (meta.pflag)
		s = 0.95;
		printscale = 3.5;
		pdfprint(102,'img/pattern-kc-vs-p-lorentzian',printscale,[],[],s);
		pdfprint(104,'img/pattern-kc-vs-p-bandpass',printscale,[],[],s);
		s = 1;
		pdfprint(108,'img/pattern-kc-vs-Sc-bandpass',printscale,[],[],s);
		pdfprint(108,'img/pattern-kc-vs-Sc-brownian',printscale,[],[],s);
		pdfprint(110,'img/pattern-kc-vs-Sc-bartlett',printscale,[],[],s);
		pdfprint(2e3,'img/pattern-joint-spectral-density',printscale,[],[],s);
	end
end

