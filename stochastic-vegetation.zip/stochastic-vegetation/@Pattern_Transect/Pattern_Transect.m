% Mon 10 Jan 11:11:55 CET 2022
classdef Pattern_Transect < handle
	properties
		b
		L
		S = struct();
		R = struct();
		stat = struct();
	% analysis parameters
	opt = struct( 'correctlocalmean', false ...
		     ,'fitmethod', 'ls'	...
		     ,'nb', [] ...
		     ... % levels for confidence intervals for density plots
		     , 'pp', [0.16,0.84] ...
		     , 'normalize', true ...
		     , 'r2_min', 0.5 ...
		     ... % confidence level for periodicity
		     , 'confidence_level', 0.05 ...
		     , 'template', 'bartlett' ...
		     );
	end % properties
	methods
		function obj = Pattern_Transect(varargin)
			for idx=1:2:length(varargin)
				obj = setfield_deep(obj,varargin{idx},varargin{idx+1});
			end % for idx
		end % constructor Pattern_Transect
		function n = n(obj)
			n = length(obj.b);
		end
		function x = x(obj)
			n   = obj.n;
			x   = obj.L*(0:n-1)'/n;
		end
		function [fx,msk] = fx(obj)
			%n   = obj.n;
			%x   = L*(0:n-1)'/n;
			fx  = fourier_axis(obj.L,obj.n);
			msk = fx>=0;
		end
		function df  = df(obj)
			% frequency interval (spacing of frequency bins)
			df = 1./obj.L;
		end
	end % methods
end % classdef Pattern_Transect
