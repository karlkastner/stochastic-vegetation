% 2021-07-06 15:17:53.166366045
function tab = tabulate(obj)
	tab = struct();

	% tabulate properties
	tab.biomass               = arrayfun(@(x) x.stat.biomass,obj);
	tab.f_mean                = arrayfun(@(x) x.stat.f.mean, obj);
	tab.f_std                 = arrayfun(@(x) x.stat.f.std, obj);
	tab.f_skew                = arrayfun(@(x) x.stat.f.skew, obj);
	tab.f_kurt                = arrayfun(@(x) x.stat.f.kurt, obj);
	tab.good.bandpass         = arrayfun(@(x) x.stat.good.bandpass, obj);
	tab.good.brownian         = arrayfun(@(x) x.stat.good.brownian, obj);
	tab.good.lognormal        = arrayfun(@(x) x.stat.good.lognormal, obj);
	tab.good.lorentzian       = arrayfun(@(x) x.stat.good.lorentzian, obj);
	tab.par2.bandpass         = arrayfun(@(x) x.stat.par2.bandpass,obj);
	tab.par2.brownian         = arrayfun(@(x) x.stat.par2.brownian,obj);
	tab.par2.lorentzian       = arrayfun(@(x) x.stat.par2.lorentzian,obj);
	tab.p_periodic            = arrayfun(@(x) x.stat.p_periodic, obj);
	tab.periodic              = arrayfun(@(x) x.stat.periodic, obj);
	tab.r2.bandpass           = arrayfun(@(x) x.stat.r2.bandpass, obj);
	tab.r2.brownian           = arrayfun(@(x) x.stat.r2.brownian, obj);
	tab.r2.lognormal          = arrayfun(@(x) x.stat.r2.lognormal, obj);
	tab.r2.lorentzian         = arrayfun(@(x) x.stat.r2.lorentzian, obj);
	tab.Sc.bartlett           = arrayfun(@(x) x.stat.Sc.bartlett,obj);
	tab.Sc.bandpass           = arrayfun(@(x) x.stat.Sc.bandpass,obj);
	tab.Sc.brownian           = arrayfun(@(x) x.stat.Sc.brownian,obj);
	tab.Sc.lognormal          = arrayfun(@(x) x.stat.Sc.lognormal, obj);
	tab.Sc.lorentzian         = arrayfun(@(x) x.stat.Sc.lorentzian,obj);
	tab.wavelength.filt       = arrayfun(@(x) x.stat.wavelength.filt,obj);
	tab.wavelength.bartlett   = arrayfun(@(x) x.stat.wavelength.bartlett,obj);
	tab.wavelength.bandpass   = arrayfun(@(x) x.stat.wavelength.bandpass,obj);
	tab.wavelength.brownian   = arrayfun(@(x) x.stat.wavelength.brownian,obj);
	tab.wavelength.lognormal  = arrayfun(@(x) x.stat.wavelength.lognormal, obj);
	tab.wavelength.lorentzian = arrayfun(@(x) x.stat.wavelength.lorentzian,obj);

	try % only defined for modelled patterns
	tab.celerity              = arrayfun(@(x) x.stat.celerity,obj);
	tab.corr		  = arrayfun(@(x) x.stat.corr,obj);
	catch e
	end
	tab.length_m              = arrayfun(@(x) x.L,obj);
	tab.nx                    = arrayfun(@(x) x.n,obj);
	tab.mseg                  = arrayfun(@(x) x.stat.m, obj);

end

