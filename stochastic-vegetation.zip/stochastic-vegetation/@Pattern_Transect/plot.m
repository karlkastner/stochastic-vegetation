% Tue 20 Jul 23:47:34 CEST 2021
%
% plot pattern
%
function transect_plot(obj,meta)
	% plots
	fflag = meta.pflag;

	b    = obj.b;
	R    = obj.R;
	S    = obj.S;
	stat = obj.stat;

	printf('Periodogram Statistics\n');
	printf('max Sb %f\n',stat.Sc.bartlett); %*fx(mdx));
	printf('f_mean %f\n',stat.f.mean);
	printf('f_std %f\n',stat.f.std);
	printf('sd_k %f\n',stat.f.std);

	% workaround for matlab bug mistaking pi as variable name
	pi = 3.146;
	printf('k_c BM: %g\n',2*pi*stat.fc.brownian);
	printf('lambda_c : %g\n',stat.wavelength.brownian)
	printf('Sc : %g\n',stat.Sc.brownian);
	printf('periodicity test p-value%f\n',stat.p_periodic);
%	printf('p inclusive %f\n',pi);

	printf('stationarity test p : %f\n', stat.p_stationary);
	printf('stationarity test D : %f\n', stat.D_stationary);

	scale = stat.fc.ref;
	% pattern
	x   = obj.x;
	[fx,fdx]  = obj.fx; 
	%fdx = fx>=0;
	splitfigure([2,2],[1,1],fflag);
	cla();
	drawnow();
	fdx_ = scale*(x-x(1))<meta.pattern.xlim(2);
	b_ = b(fdx_);
	b_ = b_-min(b_);
	b_ = b_/rms(b_);
	plot(scale*x(fdx_),b_,'linewidth',1.5)
	xlim(meta.pattern.xlim);
	ylim([0,3.5]);
	set(gca,'ytick',meta.pattern.ytick);
	xlabel(meta.pattern.xlabel,'interpreter','latex');
	ylabel(meta.pattern.ylabel,'rot',0,'interpreter','latex');
	drawnow();

	% periodogram and density
	splitfigure([2,2],[1,2],fflag);
	cla();
	drawnow();
	if (stat.p_periodic < obj.opt.confidence_level)
	stem(fx(fdx)/scale,obj.df*S.raw(fdx),'-','linewidth',4,'marker','none');
	ylim([0, 1.05*max(obj.df*S.raw(fdx))])
	else
	errorarea2(fx(fdx)/scale,scale*[S.c(fdx,1),zeros(size(S.c(fdx),1),1),S.c(fdx,2)],meta.areacol,'FaceAlpha',1)
	hold on;
	plot(fx(fdx)/scale,scale*S.raw(fdx),'k-','linewidth',1);
	plot(fx(fdx)/scale,scale*S.ref(fdx),'r','linewidth',1.5);
	ylim(meta.periodogram.ylim);
	end
	set(gca,'ytick',meta.periodogram.ytick);
	xlabel(meta.periodogram.xlabel,'interpreter','latex')
	ylabel(meta.periodogram.ylabel,'rot',0,'interpreter','latex');
	xlim(meta.periodogram.xlim)
	vline((1:10),'linestyle','--','color','k')
	drawnow();

	% autocorrelation
	splitfigure([2,2],[1,3],fflag);
	cla();
	drawnow();
	if (stat.p_periodic < obj.opt.confidence_level)
	R.rate = acf_decay_rate(x,R.raw);
	plot(x*scale, R.raw, 'linewidth',1.5);
	hold on;
	h = plot(x*scale,exp(-R.rate*x),'k--','linewidth',1.5);
else
	plot(x*scale,R.ref,'linewidth',1.5);
	hold on
	if (~isempty(stat.acf_decay_rate))
	h   = plot(x*scale,exp(-stat.acf_decay_rate*x),'k--','linewidth',1.5);
	end
end
	h.HandleVisibility = 'off';
	xlim(meta.acf.xlim);
	ylim(meta.acf.ylim);
	ytick(meta.acf.ytick);
	xlabel(meta.acf.xlabel,'interpreter','latex');
	ylabel(meta.acf.ylabel,'rot',0,'interpreter','latex');
	hline(0);
	drawnow()
	

	% QQ-plot
	fdx = (fx>=0);
	m = sum(fdx);
	pq = (1:m)'/(m+1);
	a = 1;                                                          
	b_ = (stat.m-1);                                                     
	qbeta = stat.m*betainv(pq,a,b_);
	d1 = 2;
	d2 = 2*(stat.m-1);
	qfisher = finv(pq,d1,d2);
	qchi2 = 1/2*chi2inv(pq,2);

	% note : for bartlett, the distribution is not beta,
	%        only close to beta for a small number of splits
	% the distribution is exactly beta for smoothing
	if (true) %nargin()<6)
		% empirical
		qref = qbeta;
		S.ref = S.bartlett;
		S.ref = S.filt;
		%S.ref = qfisher;
	else
		% exact
		qref = qchi2;
		S.ref = S.ref;
	end

	%figure(200)
	%clf();
	splitfigure([2,2],[2,1],fflag);
	cla();
	plot(pq,1/2*chi2inv(pq,2));
	hold on;
	plot(pq,sort(S.raw(fdx)./S.flat(fdx)));
	plot(pq,sort(S.raw(fdx)./S.bartlett(fdx)));
if (0)
	plot(pq,sort(S.raw(fdx)./S.mui(fdx)));
end
	
	splitfigure([2,2],[2,2],fflag);
	cla();
	h = plot([0,20],[0,20],'linewidth',0.5);
	h.HandleVisibility='off';
	hold on;
	plot(qchi2,sort(S.raw(fdx)./S.flat(fdx)),'.k','linewidth',1.5);
	leg_C = {'flat'};
	%plot(qbeta,sort(S.raw(fdx)./S.mui(fdx)),'.b','linewidth',1.5);
	plot(qref,sort(S.raw(fdx)./S.ref(fdx)),'.r','linewidth',1.5);
	leg_C{end+1} = 'empirical';
	if (0)
	plot(1/2*chi2inv(p,2),sort(S.raw(fdx)./S.f(fdx,2)),'.b','linewidth',1.5);
	leg_C{end+1} = {'lorentzian'};
	end
	xlabel('expected quantile');
	ylabel('sample quantile');
	axis(8*[0,1,0,1]);
	axis equal;
	axis square;
	legend(leg_C{:},'location','southeast');
	set(gca,'colororder',meta.colororder);
	
	% stationarity
	%figure(300);
	%clf
	nb=5;
	splitfigure([2,2],[2,3],fflag);
	cla
	try
		q = periodogram_qq(b,nb);
		plot(q(:,1),q(:,2),'.');
		hold on;
		mq=1.05*(max(q(:)));
		plot([0,mq],[0,mq],'k');
		axis square;
		axis([0,mq,0,mq])
		xlabel('expexcted')
		ylabel('sampled');
	catch e
		e
	end
	
	% average band shape
	splitfigure([2,2],[2,4],fflag);
	cla
	nf = 100;
	[y_mu,y_sd,yy] = average_wave_shape(b,nf);
	y_mu = circshift(y_mu,+15);
	y_mu = trifilt1([y_mu;y_mu;y_mu],21);
	y_mu = y_mu(nf+1:2*nf);
	y_mu = y_mu/rms(y_mu);
	n = length(y_mu);
	x = linspace(0,1,nf)';
	plot(x,y_mu,'linewidth',1.5);
	ylim([0,max(y_mu)*1.02])
	%xlabel(meta.pattern.xlabel);
	%ylabel(meta.pattern.ylabel);
	%plot(([circshift(y_sd./sqrt(size(yy,2)),+11),circshift(y_mu,+11)]./mean(y_mu)))
	
	% QQ
	if (meta.pflag)
		sp = meta.plotscale;
		ar = meta.aspect;
		pdfprint(11,[basename,'-pattern.pdf'],sp,ar);
		pdfprint(12,[basename,'-spectral-density.pdf'],sp,ar);
		pdfprint(13,[basename,'-autocorrelation.pdf'],sp,ar);
		pdfprint(22,[basename,'-qq.pdf'],sp,ar);
%	pdfprint(100,'img/observed-pattern-stationarity-qq.pdf',sp);
	%	pdfprint(24,[basename,'-shape.pdf'],sp);
	end

