#!/usr/bin/python3
# Mon 25 Oct 15:08:44 CEST 2021
# Karl Kastner
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# 
# fetch vegetation patterns from the google tile serverr and extract transects

import matplotlib.pyplot
import matplotlib.image
from   qgis.core import *
from   qgis.core import QgsVectorLayer,QgsProject,QgsApplication,QgsRasterLayer
from   PyQt5.QtCore import *
from   PyQt5.QtGui import *
import qgis.utils
import time
import os
import numpy
import math
import scipy.io
from   PIL import Image
import requests 

show = False

# sampling interval
dx      = 2
dx_peru = 0.5;
dy      = dx
width_m = 1e3;

dmin = 2e-5;

#base_str    = '/tmp/';
base_str    = './'

# note: the input file dat/vegetation-patterns-lines.shp has to be provided
transect_str = base_str + '/dat/vegetation-patterns-lines-merged.shp'
# will be created
project_str  = base_str + '/dat/vegetation-transects.qgz'
# output basename for fetched images with transects
img_str     = base_str + '/img/transects/' + str(dx) + '/pattern_'
imgr_str     = base_str + '/img/transects/' + str(dx) + 'r/pattern_'
# output file name for sampled transects in matlab format
mat_str     = base_str + '/mat/patterns-sampled.mat'

# google_url of google maps tile server
google_url = "mt1.google.com/vt/lyrs=s&x={x}&y={y}&z={z}" 
google_url = requests.utils.quote(google_url)
google_url = 'type=xyz&url=https://'+google_url;

# create output folders
folder_a = ["/mat", "/dat", "/img/transects"]
for folder_str in folder_a:
	if (not os.path.exists(base_str + "/" +folder_str)):
		os.mkdir(base_str + "/" + folder_str)
	# end if
# end for d in a

# initialize QGIS
qgs = QgsApplication([], False)
qgs.initQgis()

# create a project
project = QgsProject.instance() 

# add google tile server as layer
google_layer = QgsRasterLayer(google_url, 'google-satellite', 'wms')  
if google_layer.isValid():
	QgsProject.instance().addMapLayer(google_layer)
else:
	raise Exception('Connection to google-tile server failed');
# end if
# alternatively, load it from the project
# google_layer   = QgsProject.instance().mapLayersByName("google-satellite")[0]

# open the transect vector coordinates
transect_layer = QgsVectorLayer(transect_str, 'borders', 'ogr')
if not transect_layer.isValid():
	raise Exception('Layer is invalid')

# read in transect coordinates
feature_a = transect_layer.getFeatures()
bb_a = []
xy = []
xyc = []
id_a = [];
region_a = [];
length_a = [];
continent_a = [];
name_a= [];
i = 0;
print('Reading transects coordinates');
for feature in feature_a:
	# todo call by name
	id_a.append(feature.attributes()[0]);
	length_a.append(feature.attributes()[1]);
	region_a.append(feature.attributes()[2]);
	continent_a.append(feature.attributes()[3]);
	mp = feature.geometry().asMultiPolyline()
	xy.append([mp[0][0].x(), mp[0][1].x(), mp[0][0].y(), mp[0][1].y()])
	xyc.append([ (xy[i][0]+xy[i][1])/2, (xy[i][3]+xy[i][2])/2]);
	name_str = ("%+09.5f" % xyc[i][1]) + "_" + ("%+010.5f" % xyc[i][0]);
	name_a.append(name_str);
	x1 = mp[0][1].x();
	y1 = mp[0][1].y();
	if (abs(x1-mp[0][0].x())<dmin):
		x1 = mp[0][0].x() + dmin;
	#
	if (abs(y1-mp[0][0].y())<dmin):
		y1 = mp[0][0].y()+dmin;
	#
	bb = QgsRectangle(mp[0][0].x(), mp[0][0].y(),
                          x1, y1)

	# transform to the coordinate system used by the tile server
	source_crs = QgsCoordinateReferenceSystem("EPSG:4326")
	dest_crs   = QgsCoordinateReferenceSystem("EPSG:900913")
	transform  = QgsCoordinateTransform(source_crs, dest_crs, QgsProject.instance())
	bb         = transform.transformBoundingBox(bb)
	bb_a.append(bb)
	i = i+1
# end for feature

# fetch snapshots from google
print('Fetching images');
options = QgsMapSettings()
options.setLayers([google_layer])
options.setBackgroundColor(QColor(255, 255, 255))
for i in range(len(bb_a)):
	bb = bb_a[i]
	if (continent_a[i] == "South America"):
		dx_ = dx_peru;
		dy_ = dx_peru;
	else:
		dx_ = dx;
		dy_ = dx;
	# end
	#id_str = ("%03d" % id_a[i])
	oname = (img_str + name_a[i] + '.png')
	if (not os.path.exists(oname)):
		print(str(i) + " " + name_a[i])

		# todo set according to bb
		lx = round((bb.xMaximum() - bb.xMinimum())/dx_)
		ly = round((bb.yMaximum() - bb.yMinimum())/dy_)
		size    = QSize(lx,ly)
		# TODO, pseudo mercator should be used here
		options.setDestinationCrs(QgsCoordinateReferenceSystem("EPSG:900913"))
		options.setOutputSize(size)
		options.setExtent(bb)
		
		# render and save image
		img = QImage(size, QImage.Format_ARGB32_Premultiplied)
		painter = QPainter()
		painter.begin(img)
		#p.setRenderHint(QPainter.Antialiasing)
		render = QgsMapRendererCustomPainterJob(options, painter)
		
		render.start()
		render.waitForFinished()
		painter.end()
	
		# save image bounding box coordinates
		img.save(oname)
		pgw = QgsMapSettingsUtils.worldFileContent(options)
		pgw_str = (img_str + name_a[i] + '.pgw')
		#pgw_str = (img_str + id_str + '.pgw')
		with open(pgw_str, "w") as f:
		    f.write(pgw)
		time.sleep(1)
	# end of if not exists

	oname = (imgr_str + name_a[i] + '.png')
	if (not os.path.exists(oname)):
		print(str(i) + " " + str(i/len(bb_a)) + " " + oname)
		# oblique projection (two point)
		# proj   = "+proj=omerc"  \
		proj   = "+proj=tpeqd"  \
			 + " +lon_1=" + str(xy[i][0]) \
			 + " +lat_1=" + str(xy[i][2]) \
			 + " +lon_2=" + str(xy[i][1]) \
			 + " +lat_2=" + str(xy[i][3]) \
			 + " +x_0=0 +y_0=0" \
			 + " +ellps=GRS80" \
			 + " +units=m" \
			 + " +no_defs"
			 # + " +R=6371000" \
			 #   \ #"+k=1"
			 # \ # "+towgs84=0,0,0,0,0,0,0"

		source_crs = QgsCoordinateReferenceSystem("EPSG:900913")
		dest_crs   = QgsCoordinateReferenceSystem()
		dest_crs.createFromProj(proj)
		options.setDestinationCrs(dest_crs);
	
		transform  = QgsCoordinateTransform(source_crs, dest_crs, QgsProject.instance())
		bb         = transform.transformBoundingBox(bb)
		bb = QgsRectangle(bb.xMinimum(), -width_m/2,
				   bb.xMaximum(),                  
	                          width_m/2)
		lx = round((bb.xMaximum() - bb.xMinimum())/dx_)
		ly = round((bb.yMaximum() - bb.yMinimum())/dy_)
		size    = QSize(lx,ly)
		options.setOutputSize(size)
		options.setExtent(bb)
	
		# render and save image
		img = QImage(size, QImage.Format_ARGB32_Premultiplied)
		painter = QPainter()
		painter.begin(img)
		#p.setRenderHint(QPainter.Antialiasing)
		render = QgsMapRendererCustomPainterJob(options, painter)
		
		render.start()
		render.waitForFinished()
		painter.end()
	
		# save image bounding box coordinates
		img.save(oname)
		pgw = QgsMapSettingsUtils.worldFileContent(options)
		pgw_str = (imgr_str + name_a[i] + '.pgw')
		#pgw_str = (img_str + id_str + '.pgw')
		with open(pgw_str, "w") as f:
		    f.write(pgw)
		time.sleep(1)
	# if not imgr
# end for i

def sample_transect(i1,j1,i2,j2):
	di = (i2-i1)
	dj = (j2-j1)
	l  = math.hypot(di,dj)
	v  = numpy.empty(math.floor(l))
	# sample the current transect
	for k in range(0,math.floor(l)):
		# todo, bilinear interpolation
		i = i1 + di*k/l
		j = j1 + dj*k/l
		v[k] = arr[round(i),round(j)]
	# mark transect in image
	if show:
		# has to be in a separate loop as the same point might be sampled twice
		for k in range(0,math.floor(l)):
			i = i1 + di*k/l
			j = j1 + dj*k/l
			arr[round(i),round(j)] = 0
		# end of for k
	# end of if show
	return v
# end def sample_transect

print('Sampling transects');
# sample the transects
transect_C = []
transectr_C = []
for i in range(len(bb_a)):
	dx = xy[i][1] - xy[i][0]
	dy = xy[i][3] - xy[i][2]

	#id_str = ("%03d" % id_a[i])
	oname = (img_str + name_a[i] + '.png')
	if (os.path.exists(oname)):
		img   = image = Image.open(oname).convert("L")
		arr_   = numpy.asarray(image)
		arr = numpy.copy(arr_)
		siz   = [len(arr),len(arr[0])]
		# the transects follow the image diagonal, but there are two
		# select the correct one
		if (dx*dy > 0):
			v = sample_transect(0,siz[1]-1,siz[0]-1,0)
		else:
			v = sample_transect(0,0,siz[0]-1,siz[1]-1)
		# end of else of if dx>dy
		transect_C.append(v)
	
		if (show):
			matplotlib.pyplot.figure()
			matplotlib.pyplot.subplot(1,2,1)
			matplotlib.pyplot.imshow(arr)
			matplotlib.pyplot.subplot(1,2,2)
			matplotlib.pyplot.plot(range(0,len(v)),v)
			time.sleep(2)
		# end of if show
	else:
		print("Warning: File " + oname + " does not exist")
	# end if exists oname
	oname = (imgr_str + name_a[i] + '.png')
	if (os.path.exists(oname)):
		img   = image = Image.open(oname).convert("L")
		arr_  = numpy.asarray(image)
		arr   = numpy.copy(arr_)
		siz   = [len(arr),len(arr[0])]
		# the transects follow the image diagonal, but there are two
		# select the correct one
		#if (dx*dy > 0):
		v = sample_transect(0,math.floor(siz[1]/2), 
					    siz[0],math.floor(siz[1]/2))
		#else:
		#	v = sample_transect(0,0,siz[0]-1,siz[1]-1)
		# end of else of if dx>dy
		transectr_C.append(v)
	
		if (show):
			matplotlib.pyplot.figure()
			matplotlib.pyplot.subplot(1,2,1)
			matplotlib.pyplot.imshow(arr)
			matplotlib.pyplot.subplot(1,2,2)
			matplotlib.pyplot.plot(range(0,len(v)),v)
			time.sleep(2)
		# end of if show
	else:
		print("Warning: File " + oname + " does not exist")
# end for i in

if (show):
	matplotlib.pyplot.show()
# end of if show

print('Writing output');

# save sampled transects as mat-file
scipy.io.savemat(mat_str,
	{  'xy':xy
	 , 'transect_C': transect_C
	 , 'transectr_C': transectr_C
	 , 'length': length_a
	 , 'continent': continent_a
	 , 'region': region_a
	})

# save project
project.write(project_str);

qgs.exitQgis();

