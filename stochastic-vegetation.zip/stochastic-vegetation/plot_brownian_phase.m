% 2021-08-28 14:43:20.338613448 +0200

function plot_brownian_phase(meta)
	
	if (nargin<1)
		meta = vegetation_metadata();
	end
	pflag = meta.pflag;
	fflag = pflag;

	fc = meta.example.fc;
	L  = meta.example.L;
	dx = meta.example.dx;
	Sc_fc = meta.example.Sc_fc;

	% stadard deviation (second parameter)
	% TODO parametrisation has changed, so change accordingly
	[f0,s] = sd_bm_mode2par(fc,Sc_fc/fc)
	s = pi^2./s;
	s  = 1.8*0.25*4*2

	n  = L/dx;
	% plot options
	lw = 1.5;
	
	k = 15;
	rng(k);
	
	[x,b,phi] = fourier_random_phase_walk(1,0,f0,s,L,dx);
	fx     = fourier_axis(x);
	S      = periodogram(b-mean(b),L);
	% lorentzian fit
	% TODO analytic value of p from s
	par0 = [0.5*wmean(S(fx>0),fx(fx>0)),100];
	% TODO should be brownian not lorentzian
	[p,Sl]= fit_spectral_density(fx,S,par0,L,'f','lorentzian','ls');
	
	% nb = 10
	b=circshift(b,-100);
	t = Pattern_Transect('b',b,'L',L,'S.true',Sl,'opt.basename','img/brownian-phase');
	t.analyze();
	t.plot(meta);
	%[S,R,stat] = transect_analyze(b,L,Sl,meta.aopt);
	%transect_plot(S,R,stat,'img/brownian-phase',meta);
	
	if (0)
	theta = innerspace(0,2*pi,1e3)';
	p = wnormpdf(theta,0,2*pi*s,10);                                      
	C = sum(p.*cos(theta))/sum(p);
	hold on
	hp = plot([xmax,xmax],[0,C],'b','linewidth',1.5);
	hp.HandleVisibility='off';
	text(xmax-0.2,C/2,'$$E[\cos(\Delta \varphi)]$$','interpreter','latex');
	C
	Rmax
	e=std(diff(phi))/(2*pi)
	end
	
	s = linspace(1e-3,0.5);
	theta = innerspace(0,2*pi,1e3)';
	for idx=1:length(s)
		p = wnormpdf(theta,0,2*pi*s(idx),100);                                      
		C(idx,1) = sum(p.*cos(theta))/sum(p);
	end
	
	ds = s(2)-s(1);
	[dc_ds,mdx] = min(cdiff(C)./ds);
	c0 = C(mdx)-dc_ds*s(mdx);
	if (0)
	s_(1) = (1-c0)/dc_ds;
	s_(2) = s(mdx);
	s_(3) = -c0/dc_ds;
	c_ = interp1(s,C,s_);
	s_
	c_
	else
		c_(1) = 0.5;
		s_ = interp1(C,s,c_);
	end
	
	splitfigure([2,2],[10,1],fflag);
	cla
	plot(s,C,'linewidth',1.5);
	ylabel('$$R_{\textrm{max}} = E[cos(\varphi)]$$','interpreter','latex');
	xlabel('$$s_\lambda = \frac{\textrm{std}(\Delta \varphi)}{2 \pi}$$','interpreter','latex')
	hold on;
	vline(s_,'color',[0.5,0.5,0.5],'linestyle','-');
	hline(c_,'color',[0.5,0.5,0.5],'linestyle','-')
	%vline(s(mdx))
	%hline(c0)
	if (0)
		plot(s,c0 + s*dc_ds,'k--','linewidth',1.5)
	end
	ylim([0,1]);
	%c_(1) = c0;
	%c_(2) = 1;
	%c_(3) = 0;
	plot(s_,c_,'ro','markerfacecolor','r');
	%xlabel('$$s_\lambda = \frac{\textrm{std}((\varphi(x)-\varphi(x+\lambda)))}{2 \pi}$$','interpreter','latex')
	xlim([0,0.5]);
	if (0)
	
	
	n = 1100;
	n_ = 100;
	L = 1;
	dx = 0.01;
	f = 1;
	
	s = 0;
	ds = 0.05;
	%s = [1e-3,ds:ds:0.75]';
	s = [1e-3,0.15:0.15:0.3]';
	s = [1e-3,0.25]';
	%^[0.1,0.2,0.3,0.4,0.5];
	
	R = [];
	C = [];
	for idx=1:length(s)
	
	[xi,yi,phi] = fourier_random_phase_walk(1,0,f0,s,L*n,dx);
	
	k=1/dx;
	C(idx,1) = mean(cos([phi(1:end-k+1) - phi(k:end)]));
	%C(idx,2) = mean(cos(wrapToPi(phi(1:end-k+1) - phi(k:end))));
	theta = innerspace(0,2*pi)';
	p     = wnormpdf(theta,0,2*pi*s(idx),100);
	C(idx,2) = sum(p.*cos(theta))/sum(p);
	
	figure(3);
	subplot(3,ceil(length(s)/3),idx)
	cla
	for jdx=1:3
	p = wnormpdf(theta,0,2*pi*s(idx),jdx);
	plot(theta,p)
	hold on
	end % for jdx
	
	%C(idx,3) = cos(mean(wrapToPi(phi(1:end-k+1) - phi(k:end))));
	end % for idx
	
	figure(1)
	if (idx==1) clf; end
	subplot(2,2,1)
	plot(xi,yi);
	hold on
	xlim([0,2.5]);
	xlabel('$x/\lambda$','interpreter','latex');
	ylabel('$b$','interpreter','latex');
	
	subplot(2,2,2)
	plot(abs(fft(yi)))
	hold on
	
	subplot(2,2,3)
	fx = fourier_axis(xi);
	S = bartlett_periodogram(fx,yi,40);
	plot(fx,S)
	hold on
	
	subplot(2,2,4)
	a = autocorr_fft(yi,[],true);
	plot(a)
	hold on
	[r,Rmax(idx,1)] = acf_decay_rate(xi,a);
	
	
	figure(2);
	clf();
	subplot(2,2,1);
	plot(s,Rmax);
	hold on
	plot(s,C);
	legend('R','E[\Delta cos(phi)] sampled','E[\Delta cos(phi)] analytic')
	ylabel('max(R)');
	xlabel('s_x');
	
	subplot(2,2,2)
	plot(s,acos(R)/pi);
	hold on
	plot(s,s*2);
	
	end % if (0)
	
	if (pflag)
		a = meta.aspect;
		ps= meta.plotscale;
	%	pdfprint(1,'img/fourier-random-walk-spectral-density.pdf',ps,a);
	%	pdfprint(11,'img/fourier-random-walk.pdf',ps,a);
	%	pdfprint(12,'img/fourier-random-walk-acf.pdf',ps,a);
	%	pdfprint(13,'img/fourier-random-walk-rmax.pdf',2.5,a);
	end

end % plot_brownian_phase

