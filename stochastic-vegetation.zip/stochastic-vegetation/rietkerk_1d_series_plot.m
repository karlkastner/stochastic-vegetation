% 2021-07-06 15:17:53.166366045
function rietkerk_1d_series_plot(meta)

if (nargin()<1)
	meta = vegetation_metadata();
end
fflag = meta.pflag;
iflag = true;

% smoothing filter for contour plots
nf=3;

lineargs = {'ko','markersize',4,'markerfacecolor','k'};
load('mat/rietker-1d-series.mat','tab');

f = {'bandpass','lorentzian','brownian'}; 

sd_a = tab.sd_a(:,1);
vh   = tab.vh(1,:)';

% row where vh == 10
[~,pdx]=min((vh-10).^2);

for idx=1:length(f)
splitfigure([3,5],[4,idx],fflag);
%yyaxis left
cla();

% TODO convert to f0 when form is rho
if (1)
	plot(sd_a,tab.wavelength.(f{idx})(:,pdx),lineargs{:});
else
	plot(sd_a,lambda(:,1),'s','markerfacecolor','k','markersize',8);
	hold on
	plot(sd_a,lambda(:,2),'^r','markerfacecolor','r')
	plot(sd_a,lambda(:,3),'bv','markerfacecolor','b')
	legend('Bartlett','Bandpass','Lorentzian');
end
%ylabel('r_0','rot',0);
xlabel('$s_a$','interpreter','latex');
%ylabel('$\displaystyle\frac{\wavelength.c}{\textrm{m}}$','interpreter','latex','rot',0);
ylabel('$\wavelength_c/ \text{m}$','interpreter','latex','rot',90);
yl = ylim();
wavelength.t = get(gca,'ytick');
if (0)
	yyaxis right
	cla
	s=1e3;
	set(gca,'ylim',yl, ...
	'ytick',wavelength.t, ...
	'yticklabel',num2str(roundn(cvec(s./wavelength.t),2)), ...
	... 'yticklabel',num2str(cvec(1./wavelength.t),'%1.1e'), ...
	'ycolor','k');
	%ylabel('$k$','rot',0,'interpreter','latex');
	ylabel('$\displaystyle \frac{k_c}{2 \pi} 10^3\,$','rot',0,'interpreter','latex');
end

if (0)
yl = ylim;
ylim(yl);
yyaxis right
ylim(yl);
%f = get(gca,'ytick');
%la = fliplr(32*2.^(0:0.5:5));
la = fliplr([0:25:300])
f = 1./la;
set(gca,'ycolor','k');
end
end

% plot wavelength
for idx=1:3
	splitfigure([3,5],[6,idx],fflag);
	cla
	z = trifilt2(tab.wavelength.(f{idx})(:,:),nf);
	%z = trifilt2(1./par.(f{idx})(:,:,1),nf);
	contourf(sd_a,vh,z');
	h = colorbar;
	title(h,'$m$','interpreter','latex');
	title('Wavelength $\lambda$','interpreter','latex');
	xlabel('$s_a$','interpreter','latex');
	ylabel('$v_h$','rot',0,'interpreter','latex');
	if (fflag && strcmp(f{idx},'bm'))
		caxis([20,110]);colormap(parula(9));
	end
end

for idx=1:length(f)
splitfigure([3,5],[4,5+idx],fflag);
%yyaxis left
cla
if (1)
plot(sd_a,tab.par2.(f{idx})(:,pdx),lineargs{:});
ylabel(['$p_{',f{idx},'}$'],'rot',0,'interpreter','latex');
xlabel('$s_a$','interpreter','latex');
%ylim([1,3]);
else
plot(sd_a,par(:,2),'r^','markerfacecolor','r')
xlim([-0.005 max(sd_a)+0.005]);
ylim([0.5,1.05]);
ylabel('$p_B$','rot',0,'interpreter','latex');
set(gca,'ycolor','r');
hold on
fdx = par(:,2)>1.05;
o = ones(sum(fdx),1);
quiver(cvec(sd_a(fdx)),1*o,0.*o,0.04.*o,0,'k-','linewidth',2,'MaxHeadSize',0.5);
yyaxis right
cla
plot(sd_a,par.l(:,2),'bv','markerfacecolor','b');
set(gca,'ycolor','b')
ylim([1,2.8])
ylabel('$p_L$','rot',0,'interpreter','latex');
end
if (0)
yyaxis right
plot(sd_a,par(:,3),'r^','markerfacecolor','r')
set(gca,'YColor','r');
%hold on
%plot(sd_a,par(:,4),'*-b')
ylabel('s_k','rot',0)
end
end

for idx=1:length(f)
splitfigure([3,5],[4,10+idx],fflag);
%yyaxis left
cla
if (1)
y = tab.Sc.(f{idx})(:,pdx)./tab.wavelength.(f{idx})(:,pdx);
plot(sd_a,y,lineargs{:});
ylabel(['$\frac{S_c}{\lambda_c}$'],'rot',0,'interpreter','latex');
xlabel('$s_a$','interpreter','latex');
%ylim([1,3]);
else
plot(sd_a,par(:,2),'r^','markerfacecolor','r')
xlim([-0.005 max(sd_a)+0.005]);
ylim([0.5,1.05]);
ylabel('$p_B$','rot',0,'interpreter','latex');
set(gca,'ycolor','r');
hold on
fdx = par(:,2)>1.05;
o = ones(sum(fdx),1);
quiver(cvec(sd_a(fdx)),1*o,0.*o,0.04.*o,0,'k-','linewidth',2,'MaxHeadSize',0.5);
yyaxis right
cla
plot(sd_a,par.l(:,2),'bv','markerfacecolor','b');
set(gca,'ycolor','b')
ylim([1,2.8])
ylabel('$p_L$','rot',0,'interpreter','latex');
end
if (0)
yyaxis right
plot(sd_a,par(:,3),'r^','markerfacecolor','r')
set(gca,'YColor','r');
%hold on
%plot(sd_a,par(:,4),'*-b')
ylabel('s_k','rot',0)
end
end


% second parameter (filter order or phase noise sd)
for idx=1:3
	splitfigure([3,5],[6,5+idx],fflag);
	cla();
	z = tab.par2.(f{idx})(:,:);
	%z = par.(f{idx})(:,:,2);
	for jdx=1:2
		z = trifilt2(z,nf);
	end
	if (strcmp(f{idx},'bm'))
		level_a = 1:0.5:10;
	else
		level_a = 1:100;	
	end
	contourf(sd_a,vh,z',level_a);
	%	nc=9; colormap(parula(10)); caxis([1,11])
	if (fflag)
	if (strcmp(f{idx},'bm'))
%	nc=17; colormap(parula(nc-2)); caxis([1,nc]); caxis([1,nc-1])
		caxis([2,6]);
		colormap(parula(8));
	end
	end
	colorbar();
	title(['Regularity $p_{',f{idx},'}$'],'interpreter','latex');
	%title(['Regularity $p_{',f{idx},'}$'],'interpreter','latex');
	xlabel('$s_a$','interpreter','latex');
	ylabel('$v_h$','rot',0,'interpreter','latex');
end

% regularity Sc/kc
for idx=1:3
	splitfigure([3,5],[6,10+idx],fflag);
	cla();
	z = tab.Sc.(f{idx})(:,:)./tab.wavelength.(f{idx})(:,:);
	%z = par.(f{idx})(:,:,2);
	for jdx=1:2
		z = trifilt2(z,nf);
	end
	if (strcmp(f{idx},'bm'))
%		level_a = 1:0.5:10;
	else
%		level_a = 1:100;	
	end
	level_a = 0.5:0.5:3.5;
	contourf(sd_a,vh,z',level_a);
	%caxis([0.5,3.5]);
	%	nc=9; colormap(parula(10)); caxis([1,11])
	if (fflag)
%	if (strcmp(f{idx},'bm'))
%	nc=17; colormap(parula(nc-2)); caxis([1,nc]); caxis([1,nc-1])
		%caxis([2,6]);
		%colormap(parula(8));
		%caxis([0.5,3.5]);
		colormap(parula(6))
	level_a = linspace(0.5,3.5,6);contourf(sd_a,vh,z',level_a); colormap(parula(6))
	caxis([0.5,3.5]);
%	end
	end
	colorbar();
	title(['Regularity $\displaystyle{S_c / \lambda_c}$'],'interpreter','latex');
	%title(['Regularity $\displaystyleS_c \frac{k_c}{2\,\pi}$'],'interpreter','latex');
	xlabel('$s_a$','interpreter','latex');
	ylabel('$v_h$','rot',0,'interpreter','latex');
end


splitfigure([3,5],[4,4],fflag);
cla();
plot(sd_a,1e3*mean(tab.celerity(:))*tab.celerity(:,pdx),lineargs{:});
%'o','markersize',ms);
%plot(sd_a,mean(cc(:))*cc,'o','markerfacecolor','k','markersize',ms);
%plot(sd_a,tab.celerity(1).*tab.celerity,'o','markerfacecolor','k','markersize',ms);
%ylabel('$\displaystyle \frac{c}{\textrm{mm/d}}$','rot',0,'interpreter','latex');
ylabel('$c / \textrm{(mm/d)}$','rot',90,'interpreter','latex');
xlabel('$s_a$','interpreter','latex');
if (fflag)
caxis([0,20]); colormap(parula(10));
end

splitfigure([3,5],[6,4],fflag);
cla();
z = trifilt2(mean(tab.celerity(:))*tab.celerity,nf);
% m/d to mm/d
%level = 0:18;
level=0:0.1:0.7; 
%linspace(0,0.8,9),
%cla;contourf(sd_a,vh,1e3*z',l);
contourf(sd_a,vh,1e3*z',level);
if (fflag)
	colormap(parula(length(level)));
	%caxis([0.0,18]);
	caxis([level(1),level(end)]);
end

ch=colorbar();
set(ch,'xtick',level)
title(ch,'$mm/d$','interpreter','latex');
title('Celerity $c$','interpreter','latex')
xlabel('$s_a$','interpreter','latex');
ylabel('$v_h$','rot',0,'interpreter','latex');

splitfigure([3,5],[4,9],fflag);
plot(sd_a,tab.corr(:,pdx,1),lineargs{:});
%'o','markersize',ms);
%plot(sd_a,corr_(:,:,1),'o','markerfacecolor','k','markersize',ms);
ylabel('corr(b,a)')
%ylim([-0.1,1.05]);
ylim([-0.01,1.01]);
xlabel('$s_a$','interpreter','latex');
hline(0.5,'linestyle','--','color','k')
if (0)
yyaxis right
plot(sd_a,corr_(:,2),'^','markerfacecolor','r');
ylabel('corr(b,a)')
ylim([-0.1,1.05]);
end
if (0)
hold on; plot(sd_a, sd_a*(sd_a' \ cc(:,2)))
end

splitfigure([3,5],[6,9],fflag);
cla
z = trifilt2(tab.corr(:,:,1),nf);
contourf(sd_a,vh,z');
colorbar;
title('$\textrm{corr}(b,a)$','interpreter','latex');
xlabel('$s_a$','interpreter','latex');
ylabel('$v_h$','rot',0,'interpreter','latex');
if (fflag)
 caxis([0,0.6]); colormap(parula(12))
end

splitfigure([3,5],[4,5],fflag);
cla
%figure(100);
%clf
%yyaxis left;
plot(sd_a,tab.biomass(:,pdx),lineargs{:});
%'o','markersize',ms);
%plot(sd_a,biomass,'o','markerfacecolor','k','markersize',ms);
xlabel('$s_a$','interpreter','latex');
%ylabel('$\frac{\mu_b}{\text{g/m}^2$','rot',90,'interpreter','latex');
%ylabel('$\displaystyle \frac{\mu_b}{{\textrm{g/m}}^2}$','rot',0,'interpreter','latex');    
ylabel('$\bar b / \textrm{(g/m$^2$)}$','rot',90,'interpreter','latex');    
yl=ylim;
if (0)
yyaxis right;
yt = 0.5:0.05:1.2;
set(gca,'ylim',yl,'ytick',mean(bb(:,1))*yt,'yticklabel',num2str(cvec(yt)),'ycolor','k');
ylabel('$\displaystyle\,\,\frac{\mu_b}{\mu_{b0}}$','rot',0,'interpreter','latex') 
end

splitfigure([3,5],[6,5],fflag);
z = trifilt2(tab.biomass,nf);
contourf(cvec(sd_a),rvec(vh),z');
h=colorbar();
title(h,'$g/m^2$','interpreter','latex');
title('Biomass $b$','interpreter','latex')
xlabel('$s_a$','interpreter','latex');
ylabel('$v_h$','rot',0,'interpreter','latex');
if (fflag)
	caxis([6,11]); colormap(parula(10))
end

if (meta.pflag)
	ps = 4;
	aspect = 4/3;
if (1)
	pdfprint(41,'img/rietkerk-1d-wavelength-bp-vs-s_a',ps,aspect);
	pdfprint(42,'img/rietkerk-1d-wavelength-l-vs-s_a',ps,aspect);
	pdfprint(43,'img/rietkerk-1d-wavelength-bm-vs-s_a',ps,aspect);
	pdfprint(46,'img/rietkerk-1d-regularity-bp-vs-s_a',ps,aspect);
	pdfprint(47,'img/rietkerk-1d-regularity-l-vs-s_a',ps,aspect);
	pdfprint(48,'img/rietkerk-1d-regularity-bm-vs-s_a',ps,aspect);
	pdfprint(53,'img/rietkerk-1d-Sc_kc-bm-vs-s_a',ps,aspect);
	pdfprint(44,'img/rietkerk-1d-celerity-vs-s_a',ps,aspect);
	pdfprint(49,'img/rietkerk-1d-corr-b-a-vs-s_a',ps,aspect);
	pdfprint(50,'img/rietkerk-1d-biomass-vs-s_a',ps,aspect);
end
	ps = 4;
	aspect = 1.1;
	pdfprint(61,'img/rietkerk-1d-wavelength-bp-vs-s_a-and-v_h',ps,aspect);
	pdfprint(62,'img/rietkerk-1d-wavelength-l-vs-s_a-and-v_h',ps,aspect);
	pdfprint(63,'img/rietkerk-1d-wavelength-bm-vs-s_a-and-v_h',ps,aspect);
	pdfprint(66,'img/rietkerk-1d-regularity-bp-vs-s_a-and-v_h',ps,aspect);
	pdfprint(67,'img/rietkerk-1d-regularity-l-vs-s_a-and-v_h',ps,aspect);
	pdfprint(73,'img/rietkerk-1d-Sc_kc-bm-vs-s_a-and-v_h',ps,aspect);
	pdfprint(64,'img/rietkerk-1d-celerity-vs-s_a-and-v_h',ps,aspect);
	pdfprint(69,'img/rietkerk-1d-corr-b-a-vs-s_a-and-v_h',ps,aspect);
	pdfprint(70,'img/rietkerk-1d-biomass-vs-s_a-and-v_h',ps,aspect);
end
if (0)
rmse_=[rms(meanfilt1(SS-SS.l,nb));
       rms(meanfilt1(SS-SS.l,nb))]';
R2=(1-rmse_'.^2./var(meanfilt1(SS_,nb)))';
figure(100)
clf
subplot(2,2,1);
plot(sd_a,rmse_);
subplot(2,2,2);
plot(sd_a,R2), rms(rmse_(3:end,:)), mean(R2(3:end,:))
end

end % rietkerk1d_series_plot

