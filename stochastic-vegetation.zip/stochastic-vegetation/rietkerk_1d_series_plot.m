% 2021-07-06 15:17:53.166366045
%
% plot characteristics of vegetation patterns generated with the heterogeneous
% Rietkerk model
%
function rietkerk_1d_series_plot(meta)

	
	if (nargin()<1)
		meta = vegetation_metadata();
	end
	fflag = meta.pflag;
	
	% smoothing filter length for contour plots
	nf=3;
	
	lineargs = {'ko','markersize',4,'markerfacecolor','k'};
	load('mat/rietkerk-1d-series.mat','tab');
	
	f_C = {'bartlett','bandpass','lorentzian','brownian'}; 
	
	sd_a = tab.sd_a(:,1);
	vh   = tab.vh(1,:)';
	
	% row where vh == 10
	[~,pdx]=min((vh-10).^2);

	% 1D plot wavelength	
	for idx=1:length(f_C)
		splitfigure([3,6],[4,idx],fflag);
		cla();
		plot(sd_a,tab.wavelength.(f_C{idx})(:,pdx),lineargs{:});
		xlabel('$s_a$','interpreter','latex');
		ylabel('$\lambda_c/\textrm{m}$','interpreter','latex','rot',90);
	end
	
	% contour wavelength
	for idx=1:length(f_C)
		splitfigure([3,6],[6,idx],fflag);
		cla();
		z = trifilt2(tab.wavelength.(f_C{idx})(:,:),nf);
		contourf(sd_a,vh,z');
		h = colorbar();
		title(h,'$m$','interpreter','latex');
		title('Wavelength $\lambda$','interpreter','latex');
		xlabel('$s_a$','interpreter','latex');
		ylabel('$v_h$','rot',0,'interpreter','latex');
		if (fflag && strcmp(f_C{idx},'bm'))
			caxis([20,110]);colormap(parula(9));
		end
	end
	
	% 1D plot second parameter
	for idx=1:length(f_C)
	    if (~strcmp(f_C{idx},'bartlett'))
		splitfigure([3,6],[4,6+idx],fflag);
		cla()
		plot(sd_a,tab.par2.(f_C{idx})(:,pdx),lineargs{:});
		ylabel(['$p_{',f_C{idx},'}$'],'rot',90,'interpreter','latex');
		xlabel('$s_a$','interpreter','latex');
	    end % ~bartlett
	end % for idx

	% contourplot second parameter (filter order or phase noise sd)
	for idx=1:length(f_C)
	if (~strcmp(f_C{idx},'bartlett'))
		splitfigure([3,6],[6,6+idx],fflag);
		cla();
		z = tab.par2.(f_C{idx})(:,:);
		z = trifilt2(z,nf);
		if (strcmp(f_C{idx},'bm'))
			level_a = 1:0.5:10;
		else
			level_a = 1:100;	
		end
		contourf(sd_a,vh,z',level_a);
		if (fflag)
		if (strcmp(f_C{idx},'bm'))
			caxis([2,6]);
			colormap(parula(8));
		end
		end
		colorbar();
		title(['$p_{',f_C{idx},'}$'],'interpreter','latex');
		xlabel('$s_a$','interpreter','latex');
		ylabel('$v_h$','rot',0,'interpreter','latex');
	end
	end
	
	% thresholds for passing the periodicity test
	p = tab.p_periodic';
	p = trifilt2(p,3);
	p(:,end+1) = 1;
	fp = [];
	for idx=1:size(tab.p_periodic,2);
		fp(idx)=find(p(idx,:)>0.05,1,'first');
	end
	
	% 1D plot regularity
	for idx=1:length(f_C)
		splitfigure([3,6],[4,12+idx],fflag);
		cla();
		y = tab.Sc.(f_C{idx})(:,pdx)./tab.wavelength.(f_C{idx})(:,pdx);
		plot(sd_a,y,lineargs{:});
		ylabel('$\frac{S_c}{\lambda_c}$','rot',0,'interpreter','latex');
		xlabel('$s_a$','interpreter','latex');
		ylim([0,6]);
		vline(sd_a(fp(pdx)),'color','r','linewidth',1.5)
	end
	
	% 2D plot regularity Sc/lambda_c
	for idx=1:length(f_C)
		splitfigure([3,6],[6,12+idx],fflag);
		cla();
		z = tab.Sc.(f_C{idx})(:,:)./tab.wavelength.(f_C{idx})(:,:);
		z = trifilt2(z,nf);
		if (strcmp(f_C{idx},'bm'))
	%		level_a = 1:0.5:10;
		else
	%		level_a = 1:100;	
		end
		%level_a = 0.5:0.5:3.5;
		level_a = 0:1:7;
		if (~fflag)
			contourf(sd_a,vh,z',level_a);
		else
			%level_a = linspace(0.5,3.5,6);
			%level_a = linspace(0,1,7);
			contourf(sd_a,vh,z',level_a);
			%colormap(parula(6));
			colormap(parula(7));
			caxis([0,7]);
		end
		colorbar();
		title('Regularity $\displaystyle{S_c / \lambda_c}$','interpreter','latex');
		xlabel('$s_a$','interpreter','latex');
		ylabel('$v_h$','rot',0,'interpreter','latex');
		% periodicity test threshold
		hold on;
		plot(sd_a(fp),vh,'r','linewidth',2)
	end
	
	% 1D plot celerity
	splitfigure([3,6],[4,5],fflag);
	cla();
	plot(sd_a,1e3*mean(tab.celerity(:))*tab.celerity(:,pdx),lineargs{:});
	ylabel('$c / (\textrm{mm/d})$','rot',90,'interpreter','latex');
	xlabel('$s_a$','interpreter','latex');
	if (fflag)
		caxis([0,20]);
		colormap(parula(10));
	end
	
	% contourplot celerity
	splitfigure([3,6],[6,5],fflag);
	cla();
	z = trifilt2(mean(tab.celerity(:))*tab.celerity,nf);
	level=0:0.1:0.7; 
	% m/d to mm/d
	contourf(sd_a,vh,1e3*z',level);
	if (fflag)
		colormap(parula(length(level)));
		caxis([level(1),level(end)]);
	end
	ch=colorbar();
	set(ch,'xtick',level)
	title(ch,'$mm/d$','interpreter','latex');
	title('Celerity $c$','interpreter','latex')
	xlabel('$s_a$','interpreter','latex');
	ylabel('$v_h$','rot',0,'interpreter','latex');

	% 1D correlation(b,a)	
	splitfigure([3,6],[4,11],fflag);
	plot(sd_a,tab.corr(:,pdx,1),lineargs{:});
	ylabel('corr(b,a)')
	ylim([-0.01,1.01]);
	xlabel('$s_a$','interpreter','latex');
	hline(0.5,'linestyle','--','color','k')
	
	% contourplot correlation
	splitfigure([3,6],[6,11],fflag);
	cla
	z = trifilt2(tab.corr(:,:,1),nf);
	contourf(sd_a,vh,z');
	colorbar;
	title('$\textrm{corr}(b,a)$','interpreter','latex');
	xlabel('$s_a$','interpreter','latex');
	ylabel('$v_h$','rot',0,'interpreter','latex');
	if (fflag)
		caxis([0,0.6]);
		colormap(parula(12))
	end

	% periodicity test result
	splitfigure([3,6],[6,12],fflag);
 	cla();
        surf(tab.sd_a,tab.vh,double(tab.periodic),'edgecolor','none');
        axis tight;
        colorbar;
        view(0,90)
	title('Periodicity Test');	

	% 1D biomass
	splitfigure([3,6],[4,6],fflag);
	cla();
	plot(sd_a,tab.biomass(:,pdx),lineargs{:});
	xlabel('$s_a$','interpreter','latex');
	ylabel('$\bar b / (\textrm{g/m}^2)$','rot',90,'interpreter','latex');    

	% contourplot biomass	
	splitfigure([3,6],[6,6],fflag);
	z = trifilt2(tab.biomass,nf);
	contourf(cvec(sd_a),rvec(vh),z');
	h=colorbar();
	title(h,'$g/m^2$','interpreter','latex');
	title('Biomass $b$','interpreter','latex')
	xlabel('$s_a$','interpreter','latex');
	ylabel('$v_h$','rot',0,'interpreter','latex');
	if (fflag)
		caxis([6,11]); colormap(parula(10))
	end

	if (meta.pflag)
		ps = 4;
		aspect = 4/3;

		pdfprint(41,'img/rietkerk-1d-wavelength-bartlett-vs-s_a',ps,aspect);
		pdfprint(42,'img/rietkerk-1d-wavelength-bp-vs-s_a',ps,aspect);
		pdfprint(43,'img/rietkerk-1d-wavelength-lorentzian-vs-s_a',ps,aspect);
		pdfprint(44,'img/rietkerk-1d-wavelength-bm-vs-s_a',ps,aspect);
		pdfprint(45,'img/rietkerk-1d-celerity-vs-s_a',ps,aspect);
		pdfprint(46,'img/rietkerk-1d-biomass-vs-s_a',ps,aspect);
		pdfprint(53,'img/rietkerk-1d-regularity-bartlett-vs-s_a',ps,aspect);
		pdfprint(54,'img/rietkerk-1d-regularity-bp-vs-s_a',ps,aspect);
		pdfprint(55,'img/rietkerk-1d-regularity-lorentzian-vs-s_a',ps,aspect);
		pdfprint(56,'img/rietkerk-1d-regularity-bm-vs-s_a',ps,aspect);
		pdfprint(51,'img/rietkerk-1d-corr-b-a-vs-s_a',ps,aspect);

		ps = 4;
		aspect = 1.1;
		pdfprint(61,'img/rietkerk-1d-wavelength-bartlett-vs-s_a-and-v_h',ps,aspect);
		pdfprint(62,'img/rietkerk-1d-wavelength-bp-vs-s_a-and-v_h',ps,aspect);
		pdfprint(63,'img/rietkerk-1d-wavelength-lorentzian-vs-s_a-and-v_h',ps,aspect);
		pdfprint(64,'img/rietkerk-1d-wavelength-bm-vs-s_a-and-v_h',ps,aspect);
		pdfprint(65,'img/rietkerk-1d-celerity-vs-s_a-and-v_h',ps,aspect);
		pdfprint(66,'img/rietkerk-1d-biomass-vs-s_a-and-v_h',ps,aspect);
		pdfprint(71,'img/rietkerk-1d-corr-b-a-vs-s_a-and-v_h',ps,aspect);

		pdfprint(73,'img/rietkerk-1d-regularity-bartlett-vs-s_a-and-v_h',ps,aspect);
		pdfprint(74,'img/rietkerk-1d-regularity-bp-vs-s_a-and-v_h',ps,aspect);
		pdfprint(75,'img/rietkerk-1d-regularity-lorentzian-vs-s_a-and-v_h',ps,aspect);
		pdfprint(76,'img/rietkerk-1d-regularity-bm-vs-s_a-and-v_h',ps,aspect);
	end

end % rietkerk1d_series_plot

