% rows    : time
% columns : space
function [phi,da_dt] = determine_angle(b)
	nt = size(b,1);
	% 
	F = fft(b').';
	% time differences
	df_dt = diff(F,[],1);
	da_dt_ = angle(df_dt);

	% for each frequency
	tdx = (1:nt)';
	a = angle(F);
	da_dt = diff(a)./(tdx(2)-tdx(1));
	% get the shift per time step
	da_dt = wrapTo2Pi(da_dt);
%plot(da_dt_(1,:))
%hold on
%plot(da_dt(1,:))
%pause


	da_dt = mean(da_dt);	

	% subtract shift
	a = a - tdx*da_dt;
	a = wrapToPi(a);

	% get the offset
	phi = mean(a);
end
