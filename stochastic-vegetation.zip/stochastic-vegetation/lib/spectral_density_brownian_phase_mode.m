% Thu  6 Jan 16:00:43 CET 2022
% Karl Kästner, Berlin
%
%% mode (maximum) of the spectral density of the fourier series with brownian phase
%
function [fc,Sc,IS] = spectral_density_brownian_phase_mode(f0,s)
	p  = s.^2/pi^3;
	p2 = p.*p;
	fc = f0.*sqrt(2*sqrt(1 + p2) - p2 - 1);
        Sc = sqrt(1 + p2)./(4*(p2 - sqrt(1 + p2) + 1));
	IS = spectral_density_brownian_phase_scale(f0,s);
	Sc = Sc./IS;
end

