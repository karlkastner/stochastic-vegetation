% 2022-01-14 19:34:38.087731800 +0100
%
%% extract dominant frequeny from a previous model run and generate a new
%% initial condition with only this frequency
%% for faster generation of asymptotic patterns
function y0 = initial_condition_from_central_frequency(obj,y)
	if (isvector(y))
		y = rvec(y);
	end
	[b,w,h]    = rk.extract1(y(end,:));
	% determine dominant wave-length
	S          = periodogram_bartlett(b-mean(b),obj.L,round(sqrt(obj.n)),onj.n); 
	[Smax,mdx] = max(S);
	fx = fourier_axis(obj.x);
	fc = fx(mdx);
	% round to nearest integer
	fc = round(obj.L*fc)/rk.L;
	%b  = 0.01*mean(b).*0.5*(1 + cos(2*pi*fc*cvec(rk.x)));
	b  = mean(b) + std(b)*sqrt(2)*(cos(2*pi*fc*cvec(rk.x)));
	w  = repmat(mean(w),rk.n,1);
	h  = repmat(mean(h),rk.n,1);
	y0 = double([b;h;w]);
	%obj.initial_condition = y0;
	%obj.init();
end

