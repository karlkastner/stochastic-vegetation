% Mon 10 Jan 16:24:35 CET 2022
function p = sd_lorentzian_max2par(fc,Sc)
	p0 = 1;
	p = fzero(@(p) sd_lorentzian_max(fc,p) - Sc,p0);
	p = abs(p);
end
