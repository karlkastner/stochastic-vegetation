% Tue 23 Nov 17:31:17 CET 2021
% Karl Kastner, Berlin
%
%% S : spectral density of the bandpass filter in continuos space
%%     limit case of the discrete bandpass for dx -> 0
%%
%% function [S,IS] = spectral_density_bandpass_continous(fx,f0,order)
%% f     : frequency (abszissa)
%% f0    : central frequncy, location of maximum on abszissa
%% order : number of times filter is applied iteratively, not necessarily integer
function [S,IS] = spectral_density_bandpass_continous(fx,f0,order,normalize)
	if (nargin()<4)
		normalize = 1;
	end

	S = (abs(fx)./(fx.^2 + f0.^2)).^(4*order);
	
	% normalize
	switch (normalize)
	case {-1}
		% do not normalize
	case {0} % analytic, for limit case df = 1/L = 0
		IS = spectral_density_bandpass_continuous_scale(f0, order);
		S = S./IS;
	otherwise % numerical, for finite L
		IS = spectral_density_area(fx, S);
		S = S./IS;
	end
end % spectral_density_bandpass_continuous

