% Thu  6 Jan 15:53:21 CET 2022
% Karl Kästner, Berlin
function [Sc,IS] = spectral_density_bandpass_continuous_max(fc,p)
	[IS] = sd_bandpass_continuous_scale(fc,p);
	Sc = 1./IS*1./(2*fc).^(4*p);
end

