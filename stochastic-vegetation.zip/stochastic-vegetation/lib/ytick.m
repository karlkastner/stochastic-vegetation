% 2021-12-22 13:30:25.464499107 +0100
% Karl Kästner, Berlin
%
%% wrapper for setting yticks
%
function ytick(tick)
	set(gca,'ytick',tick)
end
