% Wed  1 Dec 18:55:18 CET 2021
% Karl Kästner, Berlin
%
%% spectral density of a fourier series where the phase undergoes brownian motion
%% with standard deviation s per unit distance
%
function [S,I] = spectral_density_brownian_phase(fx,f0,s,normalize)
	if (nargin()<4)
		normalize = true;
	end
	p = s.^2/pi^3;
	S = (fx.^2./f0.^2 + p.^2 + 1)./( (fx.^2./f0.^2 + p.^2 - 1).^2  + 4*p.^2);
	switch (normalize)
	case {-1}
		% nothing to do
	case {0} % analytical
		I = spectral_density_brownian_phase_scale(f0,s);
		S = S./I;
	case {1} % nuermically
		I = spectral_density_area(fx,S);
		S = S./I;
	end
end % spectral_density_brownian_phase
