% Wed  1 Dec 18:55:18 CET 2021
% Karl Kästner, Berlin
function [S,I] = spectral_density_brownian_phase(fx,f0,s)
	p = pi./s.^2;
	S = (fx.^2./f0.^2 + p.^2 + 1)./( (fx.^2./f0.^2 + p.^2 - 1).^2  + 4*p.^2);
	if (isnumeric(fx))
		I = spectral_density_area(fx,S);
		S = S./I;
	else
		I = sd_bm_scale(f0,s);
		S = S./I;
	end
end % spectral_density_brownian_phase
