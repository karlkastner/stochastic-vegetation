% Thu  6 Jan 16:00:43 CET 2022
% Karl Kästner, Berlin
function [fc,Sc,IS] = sd_bm_mode(f0,s);
	p = pi./(s.*s);
	p2 = p.*p;
	fc = (f0.*sqrt(2*sqrt(1 + p2) - p2 - 1));
        Sc = sqrt(p2 + 1)./(4*(p2 - sqrt(p2 + 1) + 1));
	IS = sd_bm_scale(f0,s)
	Sc = Sc./IS;
end

