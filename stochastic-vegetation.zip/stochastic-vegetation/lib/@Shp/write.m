% 2016-03-08 15:54:48.903542075 +0100
% Karl Kastner, Berlin
%
%% write the shapefile to disk
%
function shp = write(shp,filename)
	shapewrite(shp,filename);
end % write

