% Thu  6 Jan 15:53:31 CET 2022
% Karl Kästner, Berlin
function [IS] = sd_bandpass_continuous_scale(fc,p)
	% avoid overflow
	p = min(p,86);
	IS = 1./(4*gamma(4*p-1)./gamma((4*p-1)/2).^2*fc.^(4*p-1));
end

