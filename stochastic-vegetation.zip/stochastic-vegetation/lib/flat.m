% 2015-01-29 11:40:07.018113895 +0100
% Karl Kästner, Berlin
function X = flat(X)
	X = X(:); 
end

