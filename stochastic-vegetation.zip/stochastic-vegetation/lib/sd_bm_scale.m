% 2022-01-06 16:55:34.460434615 +0100
% Karl Kästner, Berlin
function I = sd_bm_scale(f0,s)
	I = 1/2*f0.*s.^2;
end

