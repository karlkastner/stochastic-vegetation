% Mon 10 Jan 16:19:43 CET 2022
% Karl Kästner, Berlin
function [IS] = sd_lorentzian_scale(fc,p)
	IS = 1./(fc.*(pi + 2*atan(p)))./(2*p);
end

