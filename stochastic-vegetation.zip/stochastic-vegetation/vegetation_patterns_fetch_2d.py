#!/usr/bin/python3
# Mon 25 Oct 15:08:44 CEST 2021
# Karl Kastner
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# 
# fetch vegetation patterns from the google tile serverr and extract transects

import matplotlib.pyplot
import matplotlib.image
from   qgis.core import *
from   qgis.core import QgsVectorLayer,QgsProject,QgsApplication,QgsRasterLayer
from   PyQt5.QtCore import *
from   PyQt5.QtGui import *
import qgis.utils
import time
import os
import numpy
import math
import scipy.io
from   PIL import Image
import requests 

show = False

# sampling interval
dx      = 2
dy      = dx

#base_str    = '/tmp/';
base_str    = './'

# note: the input file dat/vegetation-patterns-lines.shp has to be provided
transect_str = base_str + 'dat/patterns-2d.shp'
# output basename for fetched images with transects
img_str     = base_str + '/img/2d/' + str(dx) + '/pattern_'

# google_url of google maps tile server
google_url = "mt1.google.com/vt/lyrs=s&x={x}&y={y}&z={z}" 
google_url = requests.utils.quote(google_url)
google_url = 'type=xyz&url=https://'+google_url;

# initialize QGIS
qgs = QgsApplication([], False)
qgs.initQgis()

# create a project
project = QgsProject.instance() 

# add google tile server as layer
google_layer = QgsRasterLayer(google_url, 'google-satellite', 'wms')  
if google_layer.isValid():
	QgsProject.instance().addMapLayer(google_layer)
else:
	raise Exception('Connection to google-tile server failed');
# end if
# alternatively, load it from the project
# google_layer   = QgsProject.instance().mapLayersByName("google-satellite")[0]

# open the transect vector coordinates
transect_layer = QgsVectorLayer(transect_str, 'borders', 'ogr')
if not transect_layer.isValid():
	raise Exception('Layer is invalid')

# read in transect coordinates
feature_a = transect_layer.getFeatures()
bb_a = []
xyc = []
name_a= [];
i = 0;
print('Reading transects coordinates');
for feature in feature_a:
	# todo call by name
	mp = feature.geometry().asMultiPolygon()
	xy = [[float("inf"),float("-inf")],[float("inf"),float("-inf")]];
	for polygon in mp:
	  for ring in polygon:
	    for point in ring:
                xy[0][0] = min(xy[0][0],point.x());
                xy[0][1] = max(xy[0][1],point.x());
                xy[1][0] = min(xy[1][0],point.y());
                xy[1][1] = max(xy[1][1],point.y());
	    # for point
          # for ring
        # for poly
#	xy_a.append(xy);
	print(xy)
	bb_a.append(QgsRectangle(xy[0][0], xy[1][0],
                          	   xy[0][1], xy[1][1]));
	xyc.append([ (xy[0][0]+xy[0][1])/2, (xy[1][0]+xy[1][1])/2]);
	name_str = ("2d_%+09.5f" % xyc[i][1]) + "_" + ("%+010.5f" % xyc[i][0]);
	name_a.append(name_str);
	i = i+1
# end for feature

## fetch snapshots from google
print('Fetching images');
options = QgsMapSettings()
options.setLayers([google_layer])
options.setBackgroundColor(QColor(255, 255, 255))
for i in range(len(bb_a)):
	bb = bb_a[i]

	# transform to the coordinate system used by the tile server
	source_crs = QgsCoordinateReferenceSystem("EPSG:4326")
	dest_crs   = QgsCoordinateReferenceSystem("EPSG:900913")
	transform  = QgsCoordinateTransform(source_crs, dest_crs, QgsProject.instance())
	bb         = transform.transformBoundingBox(bb)

	oname = (img_str + name_a[i] + '.png')
	if (not os.path.exists(oname)):
		print(str(i) + " " + name_a[i])
#
		lx = round((bb.xMaximum() - bb.xMinimum())/dx)
		ly = round((bb.yMaximum() - bb.yMinimum())/dy)
		size    = QSize(lx,ly)
#		# TODO, pseudo mercator should be used here
		options.setDestinationCrs(QgsCoordinateReferenceSystem("EPSG:900913"))
		options.setOutputSize(size)
		options.setExtent(bb)
#		
		# render and save image
		img = QImage(size, QImage.Format_ARGB32_Premultiplied)
		painter = QPainter()
		painter.begin(img)
		#p.setRenderHint(QPainter.Antialiasing)
		render = QgsMapRendererCustomPainterJob(options, painter)
		
		render.start()
		render.waitForFinished()
		painter.end()
	
		# save image bounding box coordinates
		img.save(oname)
		pgw = QgsMapSettingsUtils.worldFileContent(options)
		pgw_str = (img_str + name_a[i] + '.pgw')
		#pgw_str = (img_str + id_str + '.pgw')
		with open(pgw_str, "w") as f:
		    f.write(pgw)
		time.sleep(1)
	# end of if not exists
# end for i
#
## save project
#project.write(project_str);

qgs.exitQgis();

