% 2021-11-15 13:26:36.164103609 +0100
%
% plot parametric spectral densities with varying regularity
%
function plot_spectral_density_sets(meta)
	
	if (nargin()<1)
		meta = vegetation_metadata();
	end
	pflag = meta.pflag;
	fflag = pflag;
	lw = 1.5;
	model_C = {'BM','L'};
	n     = 1e4;
	L     = 100;
	fc    = 1;
	lambda_c = 1/fc;
	fx    = linspace(0,L,n)';

	Sc = [0.5,1,1.5];
	
	for jdx=1:length(model_C)
	model = model_C{jdx};
	switch (model)
	case{'BM'}
		[f0,s] = spectral_density_brownian_phase_mode2par(fc,Sc);
		[fc__,Sc__] = spectral_density_brownian_phase_mode(f0,s)
		S = spectral_density_brownian_phase(fx,f0,s);
	case {'L'}
		p = spectral_density_lorentzian_max2par(fc,Sc);
		S = spectral_density_lorentzian(fx,fc,p);

		fc = fc;
		Sc = spectral_density_lorentzian_max(fc,p);
	end
	lambda_c = 1./fc;
	%S_ = S./sum(S);
	splitfigure([2,2],[1,jdx],fflag);
	% do not remove, necessary for printing in correct scale
	 %figure(1);
	 cla;
	 plot(fx./fc,S./lambda_c,'linewidth',lw);
	 cm = [0,0,0;
	       0.85,0,0;
	       0,0,0.85];
	 set(gca,'colororder',cm);
	 xl = [0,5.5];
	 xlim(xl);
	 xlabel('$k\;/\;k_c$','interpreter','latex');
	 %h = legend(rats(cvec(p)));
	 %h = legend(num2str(cvec(roundn(p,2))));
	 %title(h,['$p_{',model,'}$'],'interpreter','Latex');
	 ax = gca;
	 ylabel('$\displaystyle\frac{S_c}{\lambda_c}\;\;$','rot',0,'interpreter','latex');
	if (0)
	 ax(2)=axes('position',get(ax(1),'position'),'color','none','XAxisLocation','top');
	 xlim(ax(2),xl);
	 t = [0.5,1,2,4,8];
	 set(ax(2),'xtick',t,'xticklabel',num2str(cvec(1./t)));
	 set(ax(2),'ytick',[]);
	 set(ax(1),'Box','off');
	 xlabel('\lambda / \lambda_c');
	end 
	hold on
	plot(fc,Sc,'*')
	
	 splitfigure([2,2],[1,jdx+2],fflag);
	 cla;
	 a=(real(fft(S)));
	 a=a./a(1,:);
	 plot((0:n-1)/L,a,'linewidth',lw);
	 set(gca,'colororder',cm);
	 xlim([0,1.5]);
	 ylabel('$R\;\;$','rot',0,'interpreter','latex');
	 xlabel('\lambda / \lambda_c');
	
	end
	
	if (pflag)
		ps = 3.5;
		s = 0.9;
		s = 1;
		pdfprint(11,'img/brownian-spectral-density-set',ps); %,[],[],s);
		pdfprint(13,'img/brownian-autocorrelation-set',ps);
		pdfprint(12,'img/lorentzian-spectral-density-set',ps); %,[],[],s);
		pdfprint(14,'img/lorentzian-autocorrelation-set',ps);
	end
end % plot spectral_density_sets

